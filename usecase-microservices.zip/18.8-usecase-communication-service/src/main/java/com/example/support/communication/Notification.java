package com.example.support.communication;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "notifications")
public class Notification {
	@Id
	private String id = UUID.randomUUID().toString();
	private String customerId;
	private String channel;
	private String subject;
	@Column(length = 5000)
	private String message;
	private String ticketId;
	private String status = "ACCEPTED";
	private Instant createdAt = Instant.now();

	protected Notification() {
	}

	public Notification(String c, String ch, String s, String m, String t) {
		customerId = c;
		channel = ch;
		subject = s;
		message = m;
		ticketId = t;
	}

	public String getId() {
		return id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getChannel() {
		return channel;
	}

	public String getSubject() {
		return subject;
	}

	public String getMessage() {
		return message;
	}

	public String getTicketId() {
		return ticketId;
	}

	public String getStatus() {
		return status;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}
}

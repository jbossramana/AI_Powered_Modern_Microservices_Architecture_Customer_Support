package com.example.support.communication;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/communications")
public class CommunicationController {
	private final NotificationRepository repository;

	public CommunicationController(NotificationRepository r) {
		repository = r;
	}

	public record SendRequest(@NotBlank String customerId, @NotBlank String channel, @NotBlank String subject,
			@NotBlank String message, String ticketId) {
	}

	@PostMapping("/send")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public Notification send(@Valid @RequestBody SendRequest r) {
		// Demo adapter: persist/log only. Replace with provider adapter in production.
		System.out.println("MOCK " + r.channel() + " to " + r.customerId() + ": " + r.subject() + " | " + r.message());
		return repository.save(new Notification(r.customerId(), r.channel(), r.subject(), r.message(), r.ticketId()));
	}

	@GetMapping
	public List<Notification> all() {
		return repository.findAll();
	}

	@GetMapping("/tickets/{ticketId}")
	public List<Notification> byTicket(@PathVariable String ticketId) {
		return repository.findByTicketIdOrderByCreatedAtDesc(ticketId);
	}
}

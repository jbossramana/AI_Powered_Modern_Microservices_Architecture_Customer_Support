package com.example.support.communication;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, String> {
	List<Notification> findByTicketIdOrderByCreatedAtDesc(String ticketId);
}

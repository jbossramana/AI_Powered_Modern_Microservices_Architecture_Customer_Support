from pathlib import Path
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline

BASE = Path(__file__).parent
df = pd.read_csv(BASE / "data" / "tickets.csv")
features = ["text", "planTier", "accountAgeDays", "priorTicketCount30d"]
preprocess = ColumnTransformer([
    ("text", TfidfVectorizer(ngram_range=(1, 2), min_df=1), "text"),
    ("plan", OneHotEncoder(handle_unknown="ignore"), ["planTier"]),
    ("numeric", make_pipeline(SimpleImputer(strategy="median"), StandardScaler()),
     ["accountAgeDays", "priorTicketCount30d"])
])
model = Pipeline([
    ("features", preprocess),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
])
model.fit(df[features], df["priority"])
category_model = Pipeline([
    ("features", preprocess),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
])
category_model.fit(df[features], df["category"])
BASE.joinpath("models").mkdir(exist_ok=True)
joblib.dump({"priority": model, "category": category_model, "version": "ticket-classifier-1.0"},
            BASE / "models" / "ticket_classifier.joblib")
print("Saved models/ticket_classifier.joblib")
print("NOTE: this tiny teaching dataset is not production-quality.")

from pathlib import Path
from typing import Literal
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

BASE = Path(__file__).parent
MODEL_PATH = BASE / "models" / "ticket_classifier.joblib"
app = FastAPI(title="Customer Support ML Service", version="1.0.0")
models = None

class TicketFeatures(BaseModel):
    subject: str = Field(min_length=1)
    body: str = Field(min_length=1)
    planTier: Literal["BASIC", "BUSINESS", "ENTERPRISE"] = "BASIC"
    accountAgeDays: int = Field(ge=0)
    priorTicketCount30d: int = Field(ge=0)

@app.on_event("startup")
def load_model():
    global models
    if MODEL_PATH.exists():
        models = joblib.load(MODEL_PATH)

@app.get("/health")
def health():
    return {"status": "UP", "modelLoaded": models is not None}

@app.post("/api/ml/tickets/classify")
def classify(req: TicketFeatures):
    if models is None:
        raise HTTPException(status_code=503, detail="Model not trained. Run python train.py first.")
    row = pd.DataFrame([{
        "text": req.subject + " " + req.body,
        "planTier": req.planTier,
        "accountAgeDays": req.accountAgeDays,
        "priorTicketCount30d": req.priorTicketCount30d
    }])
    priority_model = models["priority"]
    category_model = models["category"]
    priority = str(priority_model.predict(row)[0])
    category = str(category_model.predict(row)[0])
    probabilities = priority_model.predict_proba(row)[0]
    confidence = float(max(probabilities))
    return {
        "category": category,
        "priority": priority,
        "confidence": round(confidence, 4),
        "modelVersion": models["version"]
    }

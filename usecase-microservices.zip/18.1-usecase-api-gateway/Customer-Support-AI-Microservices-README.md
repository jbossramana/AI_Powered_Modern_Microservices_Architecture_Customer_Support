# AI-Powered Customer Support Platform
## Spring Boot 4.1.x · Spring AI 2.0.0 · Ollama · MCP · Supervised ML · H2-backed RAG

A reference architecture for an enterprise-style customer-support platform built from independently deployable microservices.

> **Architecture principle:** business services own business data and decisions; supervised ML classifies tickets; RAG retrieves trusted knowledge; MCP exposes explicitly permitted business capabilities to AI clients; the LLM generates the final customer-facing response.

This README defines the architecture, service boundaries, API contracts, local setup, Windows `curl.exe` examples, and production design considerations. It is an implementation blueprint: the sample URLs and JSON contracts below are the agreed interface for the project, not a claim that source code has already been generated.

---

## 1. Business scenario

A customer submits:

> I was charged twice for my subscription. The payment was deducted twice, but my account is still inactive. This is affecting our production team. Please resolve it immediately.

The platform should:

1. Accept the request through the API Gateway.
2. Ask the independent ML service to predict category and priority.
3. Create a ticket in Ticket Service.
4. Retrieve relevant support/billing policy records from the Knowledge Service (RAG).
5. Use the MCP Server to access approved ticket, billing and communication operations.
6. Verify payment facts with Billing Service.
7. Ask the Ollama LLM to compose the final response from the customer message, ML result, retrieved knowledge and verified tool results.
8. Send the response through Communication Service.
9. Persist the ticket, workflow status and audit events.

The LLM must never invent transaction facts or claim that a refund has completed when Billing Service has not confirmed it.

## 2. Architecture

```mermaid
flowchart TB
    C[Customer Web / Mobile / Agent UI] --> G[API Gateway]
    G --> A[AI Orchestrator<br/>Spring Boot + Spring AI]

    A --> ML[ML Service<br/>FastAPI + scikit-learn]
    A --> RAG[Knowledge Service<br/>H2 + retrieval]
    A --> MCPC[MCP Client<br/>Spring AI]

    MCPC <-->|Streamable HTTP / MCP| MCP[MCP Server<br/>separate Spring Boot app]
    MCP --> T[Ticket Service]
    MCP --> B[Billing Service]
    MCP --> COM[Communication Service]

    T --> TDB[(Ticket H2 DB)]
    B --> BDB[(Billing H2 DB)]
    RAG --> KDB[(Knowledge H2 DB)]
    A --> L[Ollama LLM]

    A -->|final response| COM
    COM --> CH[Email / SMS / in-app adapter]
```

### Service inventory

| Service | Suggested port | Owns | Technology |
|---|---:|---|---|
| API Gateway | 8080 | External routing and edge policies | Spring Cloud Gateway |
| AI Orchestrator | 8081 | AI workflow and final response | Spring Boot 4.1, Spring AI 2.0 |
| Ticket Service | 8082 | Tickets and ticket history | Spring Boot, Spring Data JPA, H2 |
| Billing Service | 8083 | Transactions, invoices, refund requests | Spring Boot, Spring Data JPA, H2 |
| Communication Service | 8084 | Notification requests and delivery status | Spring Boot, mock/email/SMS adapter |
| MCP Server | 8085 | AI-facing tools for business operations | Spring Boot, Spring AI MCP |
| ML Service | 8090 | Ticket classification inference | Python, FastAPI, scikit-learn |
| Knowledge Service | 8086 | Support articles and retrieval | Spring Boot, Spring AI, H2 |

Ollama normally runs locally at `http://localhost:11434`.

For a small local demo these services may run on one developer machine. They remain separate deployable processes with independent configuration and persistence.

## 3. Clear responsibility boundaries

### Ticket Service
- Create and retrieve tickets.
- Maintain status, assigned team, category and priority.
- Record ticket history and audit information.
- Does not call the LLM and does not own billing data.

### Billing Service
- Own transactions, invoices and refund requests.
- Detect duplicate transactions using business rules and transaction identifiers.
- Decide refund eligibility and execute/submit refund requests.
- The LLM must not directly update payment tables or make refund eligibility decisions.

### Communication Service
- Accept notification requests.
- Send email/SMS/in-app messages through adapters.
- Store delivery status and provider reference.
- For the demo, use a mock adapter that logs the outgoing message.

### ML Service
- Predict ticket category and priority from labelled historical examples.
- Return confidence and model version.
- Does not generate natural-language answers.
- Does not use LLM sampling settings such as temperature, top-k or top-p.

### Knowledge Service / RAG
- Store approved support policies and knowledge articles in H2.
- Retrieve relevant records for a customer question.
- Return source identifiers and text so the orchestrator can provide grounded context to the LLM.

### MCP Server
- Expose a limited set of business operations as MCP tools.
- Call Ticket, Billing and Communication services through their APIs.
- Do not connect directly to another service's H2 database.
- Apply authentication, authorization, validation, audit logging and tool-level allowlists.

### AI Orchestrator
- Coordinate the workflow.
- Call ML and Knowledge services.
- Connect to MCP Server as an MCP client.
- Invoke the LLM using Spring AI `ChatClient`.
- Validate tool results and construct the final customer-facing response.
- It is the only component that owns the generative-AI conversation logic.

## 4. End-to-end workflow

```mermaid
sequenceDiagram
    participant Customer
    participant Gateway
    participant AI as AI Orchestrator
    participant ML as ML Service
    participant Ticket as Ticket Service
    participant RAG as Knowledge Service
    participant MCP as MCP Server
    participant Billing as Billing Service
    participant LLM as Ollama
    participant Comm as Communication Service

    Customer->>Gateway: Submit support request
    Gateway->>AI: POST /api/support/resolve
    AI->>ML: Predict category and priority
    ML-->>AI: BILLING, HIGH, confidence, modelVersion
    AI->>Ticket: Create ticket
    Ticket-->>AI: Ticket T1001 created
    AI->>RAG: Retrieve relevant policy articles
    RAG-->>AI: Policy snippets + source IDs
    AI->>MCP: MCP tool calls
    MCP->>Billing: Get transactions / check duplicate
    Billing-->>MCP: Verified transaction facts
    MCP-->>AI: Tool results
    AI->>LLM: Customer + ML + RAG + verified results
    LLM-->>AI: Final response text
    AI->>Comm: Send customer response
    Comm-->>AI: Notification accepted
    AI-->>Gateway: Ticket, classification, response, status
    Gateway-->>Customer: Final response
```

### Example outcome

Illustrative verified data:
- Ticket: `T1001`
- ML category: `BILLING`
- ML priority: `HIGH`
- Two successful transactions of ₹5,000 each
- Duplicate-payment check: `true`
- Refund: requested/pending review, not completed

The LLM can then write:

> We found two successful payments of ₹5,000 for your subscription. Your issue has been registered as ticket T1001 with High Priority. Our billing team is reviewing the duplicate payment and subscription activation. A refund request is subject to billing eligibility checks. We will keep you updated.

The response is generated by the LLM, but the payment facts and refund status come from Billing Service.

## 5. Supervised ML design

Start with a small labelled dataset and make the training/inference boundary explicit.

Example CSV: `ml-service/data/tickets.csv`

```csv
text,planTier,accountAgeDays,priorTicketCount30d,category,priority
"Cannot login to the application",BASIC,90,1,TECHNICAL,MEDIUM
"Charged twice for subscription",BUSINESS,400,4,BILLING,HIGH
"Production completely down for all users",BUSINESS,700,8,TECHNICAL,CRITICAL
"Need a copy of my invoice",BASIC,120,0,BILLING,LOW
"Refund not received after cancellation",BUSINESS,300,3,BILLING,HIGH
"Please reset my password",BASIC,60,0,ACCOUNT,LOW
```

Recommended first model:
- `TfidfVectorizer` for text.
- `OneHotEncoder` for plan tier.
- `StandardScaler` for numeric features where appropriate.
- `ColumnTransformer` + `Pipeline`.
- `LogisticRegression` as a simple, interpretable baseline.
- Compare with `RandomForestClassifier` or other candidates using a held-out test set and stratified cross-validation.

Do not train or evaluate on the same examples. Track precision, recall, F1 per class and confusion matrix. Pay particular attention to recall for `CRITICAL` tickets. A low-confidence prediction should route to human review or a conservative business-rule fallback.

Prediction endpoint:

`POST http://localhost:8090/api/ml/tickets/classify`

Request:

```json
{
  "subject": "Duplicate subscription payment",
  "body": "The payment was deducted twice and the account is inactive.",
  "planTier": "BUSINESS",
  "accountAgeDays": 400,
  "priorTicketCount30d": 4
}
```

Illustrative response:

```json
{
  "category": "BILLING",
  "priority": "HIGH",
  "confidence": 0.94,
  "modelVersion": "ticket-classifier-1.0"
}
```

The confidence above is illustrative only. It must be measured from the trained model; do not hard-code it.

## 6. RAG with H2: important implementation choice

For this learning project, keep approved knowledge articles in an H2 database and retrieve them before calling the LLM.

Example table:

```sql
CREATE TABLE knowledge_article (
    id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    title VARCHAR(250) NOT NULL,
    category VARCHAR(80) NOT NULL,
    content CLOB NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    version VARCHAR(40),
    updated_at TIMESTAMP
);
```

Example records:
- `Duplicate payment policy`
- `Refund eligibility and processing time`
- `Subscription activation troubleshooting`
- `Business customer escalation policy`

### H2 retrieval options

H2 is a relational database; it is not automatically a production vector database. For a simple H2-only demo, implement **SQL/keyword retrieval**: normalize the question, search relevant article titles/categories/content using parameterized queries, rank the matches, and return the top few articles as Spring AI `Document` objects. This is a valid retrieval-augmented generation workflow, but it is lexical/SQL RAG rather than embedding-based semantic vector search.

If semantic retrieval is required while retaining H2 as the source of truth:
1. Load approved H2 articles.
2. Convert rows to Spring AI `Document` objects.
3. Generate embeddings using an embedding model.
4. Index them in a supported vector store (for example, PostgreSQL with pgvector or Qdrant).
5. Retrieve semantically relevant chunks at query time.
6. Include article IDs, versions and snippets in the LLM context.

Do not claim that H2 itself provides vector similarity search unless you have added and tested a compatible vector extension/integration.

Suggested retrieval response:

```json
{
  "query": "duplicate payment refund subscription inactive",
  "documents": [
    {
      "sourceId": "KB-101",
      "title": "Duplicate payment policy",
      "content": "When two successful charges exist for the same subscription...",
      "version": "3"
    },
    {
      "sourceId": "KB-115",
      "title": "Refund processing",
      "content": "Refund requests are reviewed by the billing team...",
      "version": "2"
    }
  ]
}
```

The LLM should cite or identify these source IDs in internal response metadata where useful. Customer-facing prose need not expose internal database details.

## 7. MCP tools

The separately deployed MCP Server can expose tools such as:

| Tool name | Input | Business service |
|---|---|---|
| `createTicket` | customer ID, subject, description, category, priority | Ticket |
| `getTicket` | ticket ID | Ticket |
| `getBillingTransactions` | customer ID | Billing |
| `checkDuplicatePayment` | customer ID, subscription ID | Billing |
| `requestRefund` | transaction IDs, reason, idempotency key | Billing |
| `sendCustomerNotification` | customer ID, channel, subject, message, ticket ID | Communication |

Tool names and descriptions must be specific. Avoid broad tools such as `executeAnything`.

### Tool safety rules
- `getBillingTransactions` can be read-only.
- `requestRefund` is a consequential action: require explicit authorization, eligibility checks, idempotency and an approval policy.
- Do not let the model invent transaction IDs or amounts.
- Validate every tool argument on the server.
- Enforce customer/tenant authorization independently of the LLM.
- Record who/what requested every operation.
- Limit tool calls and execution time.
- Never expose raw database access as an MCP tool.

For a training demo, implement refund as `createRefundRequest` with status `PENDING_REVIEW`, rather than silently moving money.

## 8. LLM final response generation

Use Ollama as the local chat model provider and Spring AI `ChatClient` in the AI Orchestrator.

Example `application.yml` (verify that the selected Ollama model is already pulled):

```yaml
server:
  port: 8081

spring:
  application:
    name: ai-orchestrator

  ai:
    ollama:
      base-url: http://localhost:11434
      chat:
        model: llama3.2:latest
      embedding:
        model: nomic-embed-text

  # MCP client connection property names should be taken from
  # the exact Spring AI 2.0.0 Streamable HTTP starter reference.
  # Do not copy a connection-level base-url property from older examples.
```

Pull models:

```bat
ollama pull llama3.2:latest
ollama pull nomic-embed-text
ollama list
```

For H2 SQL/keyword retrieval, the embedding model is not required. It becomes relevant when you add a vector store for semantic retrieval.

Example prompt-building logic (illustrative Java):

```java
String finalAnswer = chatClient.prompt()
    .system("""
        You are an enterprise customer-support assistant.

        Generate a clear, polite and concise response.

        Use only the supplied verified business results and
        retrieved knowledge. Never invent payments, refunds,
        ticket IDs, policy terms or completion statuses.

        If a refund is pending, say it is pending.
        Do not say a refund is completed unless Billing Service
        explicitly confirms completion.

        If evidence is missing or contradictory, explain that
        the issue needs human review.
        """)
    .user("""
        CUSTOMER MESSAGE:
        %s

        ML CLASSIFICATION:
        %s

        RETRIEVED KNOWLEDGE:
        %s

        VERIFIED BUSINESS TOOL RESULTS:
        %s

        TICKET CREATION RESULT:
        %s

        Write the final customer-facing response.
        """.formatted(customerMessage, mlResult, retrievedKnowledge,
                      billingToolResults, ticketResult))
    .call()
    .content();
```

This shows the final-response responsibility. In the actual project, use typed DTOs and safe serialization rather than relying on arbitrary `toString()` output.

### MCP client and tool calling in Spring AI 2.0

Spring AI 2.0 uses the `ChatClient` tool-calling flow; do not rely on the old ChatModel-internal tool execution loop from Spring AI 1.x. Configure the MCP client to discover remote MCP tools and expose the resulting `ToolCallbackProvider`/callbacks to the `ChatClient` request. Confirm the exact starter and property names against the 2.0.0 reference docs.

The orchestrator may use LLM-selected tools for flexible investigation, but deterministic actions (ticket creation, refund approval, notification delivery) should be controlled by explicit workflow code and authorization gates. Do not give the model unrestricted permission to perform irreversible actions.

## 9. REST API contracts

### Main customer-support endpoint

`POST /api/support/resolve`

Request:

```json
{
  "customerId": "C1001",
  "subscriptionId": "SUB1001",
  "subject": "Duplicate subscription payment",
  "message": "I was charged twice but my account is inactive.",
  "planTier": "BUSINESS",
  "accountAgeDays": 400,
  "priorTicketCount30d": 4,
  "channel": "EMAIL"
}
```

Illustrative response:

```json
{
  "ticketId": "T1001",
  "category": "BILLING",
  "priority": "HIGH",
  "mlConfidence": 0.94,
  "duplicatePaymentDetected": true,
  "refundRequestStatus": "PENDING_REVIEW",
  "finalResponse": "We found two successful payments...",
  "notificationStatus": "ACCEPTED"
}
```

### Supporting service endpoints

| Service | Method | Endpoint |
|---|---|---|
| Ticket | POST | `/api/tickets` |
| Ticket | GET | `/api/tickets/{ticketId}` |
| Ticket | GET | `/api/tickets/customer/{customerId}` |
| Billing | GET | `/api/billing/customers/{customerId}/transactions` |
| Billing | POST | `/api/billing/refund-requests` |
| Communication | POST | `/api/communications/send` |
| ML | POST | `/api/ml/tickets/classify` |
| Knowledge | POST | `/api/knowledge/retrieve` |
| Orchestrator | POST | `/api/support/resolve` |

The endpoint contracts should be implemented consistently in the corresponding service controllers and DTOs.

## 10. Suggested repository structure

```text
customer-support-platform/
|
+-- api-gateway/
|   +-- src/main/java/...
|   +-- src/main/resources/application.yml
|
+-- ai-orchestrator/
|   +-- src/main/java/com/example/ai/
|   |   +-- controller/
|   |   +-- service/
|   |   +-- client/
|   |   +-- config/
|   |   +-- dto/
|   |   +-- rag/
|   +-- src/main/resources/application.yml
|
+-- ticket-service/
|   +-- src/main/java/com/example/ticket/
|   |   +-- controller/
|   |   +-- service/
|   |   +-- repository/
|   |   +-- entity/
|   |   +-- dto/
|   +-- src/main/resources/
|
+-- billing-service/
|   +-- src/main/java/com/example/billing/
|   |   +-- controller/
|   |   +-- service/
|   |   +-- repository/
|   |   +-- entity/
|   |   +-- dto/
|   +-- src/main/resources/
|
+-- communication-service/
|   +-- src/main/java/com/example/communication/
|   |   +-- controller/
|   |   +-- service/
|   |   +-- adapter/
|   |   +-- dto/
|   +-- src/main/resources/
|
+-- mcp-server/
|   +-- src/main/java/com/example/mcp/
|   |   +-- tools/
|   |   +-- client/
|   |   +-- config/
|   +-- src/main/resources/application.yml
|
+-- knowledge-service/
|   +-- src/main/java/com/example/knowledge/
|   |   +-- controller/
|   |   +-- service/
|   |   +-- repository/
|   |   +-- entity/
|   |   +-- retrieval/
|   +-- src/main/resources/
|       +-- application.yml
|       +-- data.sql
|
+-- ml-service/
|   +-- app/
|   |   +-- main.py
|   |   +-- schemas.py
|   |   +-- predictor.py
|   |   +-- train.py
|   +-- data/tickets.csv
|   +-- models/
|   +-- requirements.txt
|
+-- docs/
|   +-- architecture.md
|   +-- api-contracts.md
|   +-- sequence-diagram.md
|
+-- README.md
```

## 11. Technology and dependency baseline

| Component | Version / choice |
|---|---|
| Java | Java 21 or a Java version supported by the selected Boot release |
| Spring Boot | 4.1.x |
| Spring AI | 2.0.0 |
| Spring Cloud | Select a release train explicitly compatible with the chosen Spring Boot 4.1.x patch |
| Python | Python 3.11+ |
| ML | scikit-learn, pandas, FastAPI, uvicorn |
| Local chat model | Ollama `llama3.2:latest` (or another locally supported chat model) |
| Embedding model | `nomic-embed-text` only if semantic vector retrieval is enabled |
| Demo database | H2 per service |
| Production database | PostgreSQL or an appropriate managed relational database |
| Production vector store | pgvector, Qdrant or another supported vector store |

Use the Spring AI 2.0.0 BOM and Spring Boot 4.1.x dependency management. Add only the starters required by each service. Typical Spring dependencies include Web MVC, Validation, Actuator, Data JPA and H2. The AI Orchestrator needs the Spring AI Ollama chat starter and MCP client starter; the MCP Server needs the Spring AI MCP server WebMVC/Streamable HTTP starter and annotation support appropriate to the selected 2.0.0 artifacts.

Do not blindly copy dependency coordinates from Spring AI 1.x tutorials: Spring AI 2.0 introduced package and tool-calling changes.

Official references:
- Spring AI 2.0.0 GA: https://spring.io/blog/2026/06/12/spring-ai-2-0-0-GA-available-now/
- Spring AI reference: https://docs.spring.io/spring-ai/reference/
- Spring AI upgrade notes: https://docs.spring.io/spring-ai/reference/upgrade-notes.html
- Spring Boot: https://docs.spring.io/spring-boot/

## 12. Local setup

### Prerequisites
- JDK compatible with Spring Boot 4.1.x.
- Maven 3.9+ or Maven Wrapper.
- Python 3.11+.
- Ollama installed and running.
- Git and Windows Command Prompt or PowerShell.

### Start Ollama

```bat
ollama serve
```

In another terminal:

```bat
ollama pull llama3.2:latest
ollama list
```

If semantic embeddings are enabled:

```bat
ollama pull nomic-embed-text
```

### Start Python ML service

From `ml-service`:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install fastapi uvicorn scikit-learn pandas joblib
uvicorn app.main:app --host 0.0.0.0 --port 8090 --reload
```

Train the model using the project's training command/script before enabling predictions. The model file path should be configured and checked at startup; fail clearly if the trained artifact is missing.

### Start Spring services

Open one terminal per service and run:

```bat
mvnw.cmd spring-boot:run
```

Start in this order for local convenience:
1. Ticket Service
2. Billing Service
3. Communication Service
4. Knowledge Service
5. MCP Server
6. ML Service
7. AI Orchestrator
8. API Gateway

The services should expose health endpoints through Spring Boot Actuator, for example `/actuator/health`.

## 13. Windows curl.exe testing

Use `curl.exe` explicitly in Windows PowerShell because `curl` may be an alias. The following commands assume the ports and endpoint contracts in this README.

### A. Check ML classification directly

```bat
curl.exe -i -X POST "http://localhost:8090/api/ml/tickets/classify" -H "Content-Type: application/json" -d "{\"subject\":\"Duplicate subscription payment\",\"body\":\"The payment was deducted twice and the account is inactive.\",\"planTier\":\"BUSINESS\",\"accountAgeDays\":400,\"priorTicketCount30d\":4}"
```

### B. Create a ticket directly

```bat
curl.exe -i -X POST "http://localhost:8082/api/tickets" -H "Content-Type: application/json" -d "{\"customerId\":\"C1001\",\"subject\":\"Duplicate subscription payment\",\"description\":\"Charged twice but account is inactive\",\"category\":\"BILLING\",\"priority\":\"HIGH\"}"
```

### C. Check billing transactions directly

```bat
curl.exe -i -X GET "http://localhost:8083/api/billing/customers/C1001/transactions"
```

### D. Retrieve knowledge directly

```bat
curl.exe -i -X POST "http://localhost:8086/api/knowledge/retrieve" -H "Content-Type: application/json" -d "{\"query\":\"duplicate payment refund subscription inactive\",\"topK\":3}"
```

### E. Test the MCP endpoint

MCP Streamable HTTP is a JSON-RPC protocol, not an ordinary REST controller endpoint. Use an MCP-capable client/inspector to initialize the session, list tools and call tools. Do not assume that `GET /mcp` or a normal business REST curl request is a valid tool invocation. The exact request headers/session handling depend on the configured MCP transport mode.

### F. Submit the complete customer-support request

Through API Gateway:

```bat
curl.exe -i -X POST "http://localhost:8080/api/support/resolve" -H "Content-Type: application/json" -d "{\"customerId\":\"C1001\",\"subscriptionId\":\"SUB1001\",\"subject\":\"Duplicate subscription payment\",\"message\":\"I was charged twice for my subscription, but my account is still inactive. This is affecting our production team. Please resolve it immediately.\",\"planTier\":\"BUSINESS\",\"accountAgeDays\":400,\"priorTicketCount30d\":4,\"channel\":\"EMAIL\"}"
```

Expected response shape (values are illustrative):

```json
{
  "ticketId": "T1001",
  "category": "BILLING",
  "priority": "HIGH",
  "mlConfidence": 0.94,
  "duplicatePaymentDetected": true,
  "refundRequestStatus": "PENDING_REVIEW",
  "finalResponse": "We found two successful payments...",
  "notificationStatus": "ACCEPTED"
}
```

### G. Retrieve the created ticket

```bat
curl.exe -i -X GET "http://localhost:8082/api/tickets/T1001"
```

### H. Verify notification result

```bat
curl.exe -i -X GET "http://localhost:8084/api/communications/tickets/T1001"
```

Implement this last read endpoint if you want to inspect notification delivery in the demo.

## 14. H2 console and database isolation

For local development only, each service may enable its own H2 console on a distinct path/port. Example:

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:ticketdb
    username: sa
    password:
  h2:
    console:
      enabled: true
      path: /h2-console
```

Do not expose H2 consoles in production. Do not share one H2 database between microservices. Each service owns its schema and data.

## 15. Reliability and production architecture recommendations

### Synchronous versus asynchronous work
- Use synchronous REST for request validation and short, required reads.
- Use asynchronous messaging (Kafka/RabbitMQ) for ticket-created events, notifications, analytics and long-running workflows.
- Do not hold an HTTP request open while waiting for slow email/SMS providers or human approval.
- Return a workflow/ticket ID and expose a status endpoint for long-running operations.

### Resilience
- Configure connection/read timeouts for every HTTP and model call.
- Use bounded retries with backoff only for transient failures.
- Add circuit breakers and bulkheads where appropriate.
- Use idempotency keys for ticket creation, refund requests and notifications.
- Define what happens when ML, Ollama, MCP or Knowledge Service is unavailable.
- Keep a deterministic fallback: create the ticket, apply safe business rules, and route uncertain cases to a human agent.

### Security
- Authenticate customers at the Gateway.
- Propagate identity and tenant context to downstream services.
- Authorize every business operation in the owning service.
- Protect MCP endpoints; never expose unauthenticated write tools.
- Redact payment credentials and personal data from prompts and logs.
- Store secrets outside source control.
- Treat retrieved documents and customer messages as untrusted input; defend against prompt injection.
- Maintain an audit record of tool name, caller, arguments (redacted), result, approval and correlation ID.

### Human approval
Require human approval for high-impact operations such as:
- Actual refund execution.
- Account suspension/reactivation when it has material impact.
- Changes to billing details.
- Any action outside pre-approved policy limits.

The LLM may explain and recommend an action; the business service and authorization workflow decide whether it can execute.

### Observability
Use:
- Spring Boot Actuator.
- Micrometer metrics and distributed tracing.
- OpenTelemetry-compatible tracing.
- Correlation ID propagation across Gateway, Orchestrator, MCP and downstream services.
- Structured logs with redaction.
- Metrics for ML model version, prediction latency, confidence distribution, LLM latency/token use, RAG retrieval quality, tool failures and notification delivery.

## 16. Testing strategy

1. **Unit tests:** classification mapping, priority rules, refund eligibility, retrieval ranking and prompt assembly.
2. **Service integration tests:** each service with its own test database.
3. **MCP contract tests:** tool discovery, JSON schema validation, authorization and error responses.
4. **LLM tests:** verify factual grounding, refusal to invent refund status, and behavior when evidence is missing.
5. **End-to-end tests:** duplicate payment, login failure, invoice request, refund pending and ML low-confidence scenarios.
6. **Failure tests:** Ollama unavailable, ML timeout, MCP timeout, duplicate request, notification provider failure and conflicting billing records.

Do not assert exact LLM wording in tests. Assert required facts, prohibited claims and structured workflow outcomes.

## 17. Architecture decisions summary

| Decision | Recommendation | Reason |
|---|---|---|
| Business services | Separate deployable services | Independent ownership and scaling |
| MCP | Separate application | AI integration boundary, not business database access |
| ML | Independent Python service | Model lifecycle independent of Java services |
| RAG source | H2 knowledge tables for demo | Simple local setup and clear source of truth |
| Semantic retrieval | Add a real vector store when needed | H2 relational queries are not vector similarity |
| LLM | Ollama through Spring AI | Local inference and replaceable model provider |
| Final response | Generated by LLM | Natural, contextual customer communication |
| Refund | Billing-owned, approval controlled | Financial correctness and auditability |
| Notifications | Communication service | Isolates external delivery concerns |
| Workflow | Explicit orchestration + events | Predictable side effects and recovery |

## 18. Important implementation sequence

Build incrementally rather than coding all services at once:

1. Ticket Service + H2 and its REST APIs.
2. Billing Service + seeded transaction data.
3. Communication Service with a mock sender.
4. ML Service: dataset, training, saved model and prediction API.
5. Knowledge Service: H2 article data and SQL/keyword retrieval.
6. MCP Server: expose read tools first, then controlled write tools.
7. AI Orchestrator: call ML, RAG and MCP; generate the final response with Ollama.
8. API Gateway and end-to-end Windows curl tests.
9. Add Kafka, authentication, tracing, approval workflow and production persistence.

**Final architecture rule:** ML predicts, RAG retrieves, MCP exposes capabilities, business services validate and execute, and the LLM communicates the final answer. Keep those responsibilities separate.

package com.example.support.orchestrator;

import jakarta.validation.constraints.NotBlank;

public record SupportRequest(@NotBlank String customerId, String subscriptionId, @NotBlank String subject,
		@NotBlank String message, String planTier, Integer accountAgeDays, Integer priorTicketCount30d,
		String channel) {
}


package com.example.support.orchestrator;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

@Service
public class SupportWorkflow {

	private static final Logger log = LoggerFactory.getLogger(SupportWorkflow.class);

	private final ChatClient chatClient;
	private final ToolCallbackProvider toolCallbackProvider;
	private final JsonMapper jsonMapper = JsonMapper.builder().build();

	private final RestClient mlClient;
	private final RestClient ticketClient;
	private final RestClient knowledgeClient;
	private final RestClient communicationClient;

	public SupportWorkflow(ChatClient.Builder chatClientBuilder, ToolCallbackProvider toolCallbackProvider,

			@Value("${services.ml-url:http://localhost:8090}") String mlUrl,

			@Value("${services.ticket-url:http://localhost:8082}") String ticketUrl,

			@Value("${services.knowledge-url:http://localhost:8086}") String knowledgeUrl,

			@Value("${services.communication-url:http://localhost:8084}") String communicationUrl) {

		this.chatClient = chatClientBuilder.build();
		this.toolCallbackProvider = toolCallbackProvider;

		this.mlClient = RestClient.create(mlUrl);
		this.ticketClient = RestClient.create(ticketUrl);
		this.knowledgeClient = RestClient.create(knowledgeUrl);
		this.communicationClient = RestClient.create(communicationUrl);
	}

	// =========================================================
	// MAIN SUPPORT WORKFLOW
	// =========================================================

	public Map<String, Object> resolve(Map<String, Object> request) {

		log.info("========== SUPPORT WORKFLOW STARTED ==========");

		Map<String, Object> response = new LinkedHashMap<>();

		String customerId = value(request, "customerId");
		String subscriptionId = value(request, "subscriptionId");
		String subject = value(request, "subject");
		String message = value(request, "message");
		String channel = value(request, "channel", "EMAIL");

		// -----------------------------------------------------
		// STEP 1: ML CLASSIFICATION
		// -----------------------------------------------------

		log.info("STEP 1: ML classification");

		Map<String, Object> mlRequest = new LinkedHashMap<>();

		mlRequest.put("subject", subject);
		mlRequest.put("body", message);
		mlRequest.put("planTier", value(request, "planTier", "STANDARD"));
		mlRequest.put("accountAgeDays", request.getOrDefault("accountAgeDays", 0));
		mlRequest.put("priorTicketCount30d", request.getOrDefault("priorTicketCount30d", 0));

		Map<String, Object> mlResult = post(mlClient, "/api/ml/tickets/classify", mlRequest);

		String category = value(mlResult, "category", "GENERAL");
		String priority = value(mlResult, "priority", "MEDIUM");

		Object confidence = mlResult.get("confidence");

		log.info("ML category: {}", category);
		log.info("ML priority: {}", priority);
		log.info("ML confidence: {}", confidence);

		response.put("category", category);
		response.put("priority", priority);
		response.put("mlConfidence", confidence);

		// -----------------------------------------------------
		// STEP 2: CREATE SUPPORT TICKET
		// -----------------------------------------------------

		log.info("STEP 2: Creating support ticket");

		Map<String, Object> ticketRequest = new LinkedHashMap<>();

		ticketRequest.put("customerId", customerId);
		ticketRequest.put("subject", subject);
		ticketRequest.put("description", message);
		ticketRequest.put("category", category);
		ticketRequest.put("priority", priority);
		ticketRequest.put("channel", channel);

		Map<String, Object> ticketResult = post(ticketClient, "/api/tickets", ticketRequest);

		String ticketId = value(ticketResult, "ticketId", value(ticketResult, "id", null));

		log.info("Ticket created: {}", ticketId);

		response.put("ticketId", ticketId);

		// -----------------------------------------------------
		// STEP 3: KNOWLEDGE RETRIEVAL
		// -----------------------------------------------------

		log.info("STEP 3: Knowledge retrieval");

		Map<String, Object> knowledgeRequest = new LinkedHashMap<>();

		knowledgeRequest.put("query", subject + " " + message);

		Map<String, Object> knowledgeResult = post(knowledgeClient, "/api/knowledge/retrieve", knowledgeRequest);

		log.info("Knowledge result: {}", knowledgeResult);

		// -----------------------------------------------------
		// STEP 4: MCP TOOL DISCOVERY
		// -----------------------------------------------------

		log.info("STEP 4: MCP tool discovery");

		for (ToolCallback callback : toolCallbackProvider.getToolCallbacks()) {

			log.info("Registered MCP tool: {}", callback.getToolDefinition().name());
		}

		// -----------------------------------------------------
		// STEP 5: VERIFY BILLING THROUGH MCP
		// -----------------------------------------------------

		log.info("STEP 5: Checking duplicate payment through MCP");

		Map<String, Object> billingArguments = new LinkedHashMap<>();

		billingArguments.put("customerId", customerId);
		billingArguments.put("subscriptionId", subscriptionId);

		JsonNode billingResult = invokeMcpTool("checkDuplicatePayment", billingArguments);

		boolean duplicatePayment = booleanField(billingResult, "possibleDuplicate");

		List<String> transactionIds = extractTransactionIds(billingResult);

		log.info("Duplicate payment detected: {}", duplicatePayment);

		log.info("Verified transaction IDs: {}", String.join(",", transactionIds));

		response.put("billingVerificationStatus", "VERIFIED");
		response.put("duplicatePaymentDetected", duplicatePayment);
		response.put("transactionIds", String.join(",", transactionIds));

		// -----------------------------------------------------
		// STEP 6: CREATE REFUND REQUEST
		// -----------------------------------------------------

		String refundRequestId = null;
		String refundStatus = "NOT_REQUIRED";

		if (duplicatePayment && !transactionIds.isEmpty()) {

			log.info("STEP 6: Creating refund request through MCP");

			Map<String, Object> refundArguments = new LinkedHashMap<>();

			refundArguments.put("transactionIds", String.join(",", transactionIds));

			refundArguments.put("reason", message);
			refundArguments.put("customerId", customerId);

			JsonNode refundResult = invokeMcpTool("createRefundRequest", refundArguments);

			log.info("Parsed refund result: {}", refundResult);

			// IMPORTANT:
			// Billing Service returns the refund identifier as "id".

			refundRequestId = firstText(refundResult, "refundRequestId", "requestId", "id");

			refundStatus = firstText(refundResult, "status");

			if (refundStatus == null) {
				refundStatus = "UNKNOWN";
			}

			log.info("Refund status: {}", refundStatus);
			log.info("Refund request ID: {}", refundRequestId);

		} else {

			log.info("No duplicate payment found. Refund not required.");
		}

		response.put("refundRequestStatus", refundStatus);
		response.put("refundRequestId", refundRequestId);

		// -----------------------------------------------------
		// STEP 7: COLLECT VERIFIED BUSINESS FACTS
		// -----------------------------------------------------

		log.info("STEP 7: Collecting verified business facts");

		log.info("Verified billing facts: duplicate={}, transactions={}, refundStatus={}, refundId={}",
				duplicatePayment, transactionIds, refundStatus, refundRequestId);

		// -----------------------------------------------------
		// STEP 8: GENERATE CUSTOMER RESPONSE
		// -----------------------------------------------------

		log.info("STEP 8: Generating customer response");

		String knowledgeText = knowledgeResult.toString();

		String llmResponse;

		try {

			llmResponse = chatClient.prompt()

					.system("""
							You are a professional customer support assistant.

							Write a polite and empathetic response.

							Explain the issue and the next steps clearly.

							Use the supplied knowledge base information.

							Do not invent:
							- Transaction IDs
							- Refund request IDs
							- Ticket IDs
							- Refund statuses
							- Payment confirmations

							Do not claim that a refund is completed
							when its status is PENDING_REVIEW.

							Do not create or assume any business facts.
							""")

					.user("""
							Customer ID: %s

							Customer issue:
							%s

							Knowledge base information:
							%s

							Duplicate payment detected:
							%s

							Verified refund status:
							%s

							Explain the situation to the customer.
							Do not include any identifiers.
							""".formatted(customerId, message, knowledgeText, duplicatePayment, refundStatus))

					.call().content();

		} catch (Exception ex) {

			log.error("LLM response generation failed", ex);

			llmResponse = "We have reviewed your support request. " + "Our team is processing the issue and will "
					+ "provide an update.";
		}

		// Java appends authoritative identifiers.
		StringBuilder finalResponse = new StringBuilder();

		finalResponse.append(llmResponse);

		if (duplicatePayment) {

			finalResponse.append("\n\nVerified transaction IDs: ").append(String.join(", ", transactionIds));

			finalResponse.append("\nRefund request status: ").append(refundStatus);

			if (refundRequestId != null) {
				finalResponse.append("\nRefund request ID: ").append(refundRequestId);
			}
		}

		if (ticketId != null) {
			finalResponse.append("\nSupport ticket ID: ").append(ticketId);
		}

		String customerResponse = finalResponse.toString();

		log.info("Customer response generated");

		response.put("finalResponse", customerResponse);

		// -----------------------------------------------------
		// STEP 9: SEND CUSTOMER NOTIFICATION
		// -----------------------------------------------------

		log.info("STEP 9: Sending customer notification");

		Map<String, Object> notificationRequest = new LinkedHashMap<>();

		notificationRequest.put("customerId", customerId);
		notificationRequest.put("ticketId", ticketId);
		notificationRequest.put("channel", channel);
		notificationRequest.put("subject", subject);
		notificationRequest.put("message", customerResponse);

		Map<String, Object> notificationResult = post(communicationClient, "/api/communications/send",
				notificationRequest);

		String notificationStatus = value(notificationResult, "status", "UNKNOWN");

		log.info("Notification status: {}", notificationStatus);

		response.put("notificationStatus", notificationStatus);

		log.info("========== SUPPORT WORKFLOW COMPLETED ==========");

		return response;
	}

	// =========================================================
	// MCP TOOL INVOCATION
	// =========================================================

	private JsonNode invokeMcpTool(String toolName, Map<String, Object> arguments) {

		ToolCallback tool = findTool(toolName);

		if (tool == null) {
			throw new IllegalStateException("MCP tool not found: " + toolName);
		}

		try {

			String toolInput = jsonMapper.writeValueAsString(arguments);

			log.info("Found MCP tool: {}", toolName);
			log.info("Invoking MCP tool: {}", toolName);
			log.info("MCP tool arguments: {}", toolInput);

			String rawResult = tool.call(toolInput);

			log.info("Raw MCP result for {}: {}", toolName, rawResult);

			JsonNode parsedResult = parseToolResult(rawResult);

			log.info("Extracted MCP result for {}: {}", toolName, parsedResult);

			return parsedResult;

		} catch (Exception ex) {

			log.error("MCP tool invocation failed: {}", toolName, ex);

			throw new IllegalStateException("MCP tool invocation failed: " + toolName, ex);
		}
	}

	private ToolCallback findTool(String toolName) {

		for (ToolCallback callback : toolCallbackProvider.getToolCallbacks()) {

			if (callback.getToolDefinition().name().equals(toolName)) {

				return callback;
			}
		}

		return null;
	}

	// =========================================================
	// MCP RESULT PARSING
	// =========================================================

	private JsonNode parseToolResult(String rawResult) {

		try {

			JsonNode root = jsonMapper.readTree(rawResult);

			if (root == null) {
				return jsonMapper.createObjectNode();
			}

			// MCP may return content blocks as an array:
			// [{"text":"{\"id\":\"...\",\"status\":\"...\"}"}]

			if (root.isArray()) {

				for (JsonNode item : root) {

					JsonNode textNode = item.get("text");

					if (textNode != null && textNode.isTextual()) {
						return jsonMapper.readTree(textNode.asText());
					}
				}
			}

			// Handle an object containing content blocks.

			JsonNode contentNode = root.get("content");

			if (contentNode != null && contentNode.isArray()) {

				for (JsonNode item : contentNode) {

					JsonNode textNode = item.get("text");

					if (textNode != null && textNode.isTextual()) {
						return jsonMapper.readTree(textNode.asText());
					}
				}
			}

			// Handle a direct text field.

			JsonNode textNode = root.get("text");

			if (textNode != null && textNode.isTextual()) {
				return jsonMapper.readTree(textNode.asText());
			}

			return root;

		} catch (Exception ex) {

			log.error("Unable to parse MCP result: {}", rawResult, ex);

			throw new IllegalStateException("Invalid JSON returned by MCP tool", ex);
		}
	}

	// =========================================================
	// REFUND ID AND STATUS EXTRACTION
	// =========================================================

	private String firstText(JsonNode node, String... fieldNames) {

		for (String field : fieldNames) {

			JsonNode value = node.findValue(field);

			if (value != null && !value.isNull()) {

				String result = value.asText();

				if (!result.isBlank()) {
					return result;
				}
			}
		}

		return null;
	}

	private boolean booleanField(JsonNode node, String field) {

		JsonNode value = node.findValue(field);

		if (value == null || value.isNull()) {
			return false;
		}

		return value.asBoolean(false);
	}

	// =========================================================
	// TRANSACTION ID EXTRACTION
	// =========================================================

	private List<String> extractTransactionIds(JsonNode billingResult) {

		List<String> ids = new ArrayList<>();

		JsonNode transactions = billingResult.findValue("transactions");

		if (transactions == null || !transactions.isArray()) {
			return ids;
		}

		for (JsonNode transaction : transactions) {

			String status = firstText(transaction, "status");

			if (!"SUCCESS".equalsIgnoreCase(status)) {
				continue;
			}

			String transactionId = firstText(transaction, "transactionId");

			if (transactionId != null) {
				ids.add(transactionId);
			}
		}

		return ids;
	}

	// =========================================================
	// REST CLIENT HELPER
	// =========================================================

	private Map<String, Object> post(RestClient client, String endpoint, Map<String, Object> request) {

		Map<?, ?> result = client.post().uri(endpoint).body(request).retrieve().body(Map.class);

		if (result == null) {
			return new LinkedHashMap<>();
		}

		Map<String, Object> response = new LinkedHashMap<>();

		result.forEach((key, value) -> response.put(String.valueOf(key), value));

		return response;
	}

	// =========================================================
	// MAP VALUE HELPERS
	// =========================================================

	private String value(Map<String, Object> map, String key) {

		return value(map, key, null);
	}

	private String value(Map<String, Object> map, String key, String defaultValue) {

		Object result = map.get(key);

		if (result == null) {
			return defaultValue;
		}

		String text = result.toString();

		return text.isBlank() ? defaultValue : text;
	}
}

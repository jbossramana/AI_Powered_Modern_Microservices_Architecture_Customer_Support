
package com.example.support.orchestrator;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/support")
public class SupportController {

	private final SupportWorkflow workflow;

	public SupportController(SupportWorkflow workflow) {
		this.workflow = workflow;
	}

	@PostMapping("/resolve")
	@ResponseStatus(HttpStatus.OK)
	public Map<String, Object> resolve(@RequestBody Map<String, Object> request) {

		return workflow.resolve(request);
	}
}

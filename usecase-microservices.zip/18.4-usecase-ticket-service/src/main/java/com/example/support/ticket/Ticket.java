package com.example.support.ticket;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "tickets")
public class Ticket {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String customerId;
	private String subject;
	@Column(length = 4000)
	private String description;
	private String category;
	private String priority;
	private String status = "OPEN";
	private Instant createdAt = Instant.now();

	protected Ticket() {
	}

	public Ticket(String customerId, String subject, String description, String category, String priority) {
		this.customerId = customerId;
		this.subject = subject;
		this.description = description;
		this.category = category;
		this.priority = priority;
	}

	public String getId() {
		return id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getSubject() {
		return subject;
	}

	public String getDescription() {
		return description;
	}

	public String getCategory() {
		return category;
	}

	public String getPriority() {
		return priority;
	}

	public String getStatus() {
		return status;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}

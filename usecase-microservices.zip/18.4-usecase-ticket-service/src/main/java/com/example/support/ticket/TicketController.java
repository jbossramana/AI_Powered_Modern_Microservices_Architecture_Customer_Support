package com.example.support.ticket;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {
	private final TicketRepository repository;

	public TicketController(TicketRepository repository) {
		this.repository = repository;
	}

	public record CreateTicketRequest(@NotBlank String customerId, @NotBlank String subject,
			@NotBlank String description, String category, String priority) {
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Ticket create(@Valid @RequestBody CreateTicketRequest r) {
		return repository.save(new Ticket(r.customerId(), r.subject(), r.description(),
				r.category() == null ? "GENERAL" : r.category(), r.priority() == null ? "MEDIUM" : r.priority()));
	}

	@GetMapping("/{id}")
	public Ticket get(@PathVariable String id) {
		return repository.findById(id)
				.orElseThrow(() -> new org.springframework.web.server.ResponseStatusException(HttpStatus.NOT_FOUND));
	}

	@GetMapping("/customer/{customerId}")
	public List<Ticket> byCustomer(@PathVariable String customerId) {
		return repository.findByCustomerIdOrderByCreatedAtDesc(customerId);
	}

	@PutMapping("/{id}/status")
	public Ticket status(@PathVariable String id, @RequestBody StatusRequest r) {
		Ticket t = get(id);
		t.setStatus(r.status());
		return repository.save(t);
	}

	public record StatusRequest(String status) {
	}
}

package com.example.support.mcp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
public class ServiceClients {
	@Bean
	RestClient ticketRestClient(@Value("${services.ticket-url}") String url) {
		return RestClient.builder().baseUrl(url).build();
	}

	@Bean
	RestClient billingRestClient(@Value("${services.billing-url}") String url) {
		return RestClient.builder().baseUrl(url).build();
	}

	@Bean
	RestClient communicationRestClient(@Value("${services.communication-url}") String url) {
		return RestClient.builder().baseUrl(url).build();
	}
}

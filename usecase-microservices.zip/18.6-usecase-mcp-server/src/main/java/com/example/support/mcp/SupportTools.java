package com.example.support.mcp;

import org.springframework.ai.mcp.annotation.McpTool;
import org.springframework.ai.mcp.annotation.McpToolParam;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import java.util.Map;

@Component
public class SupportTools {
	private final RestClient ticket, billing, communication;

	public SupportTools(RestClient ticketRestClient, RestClient billingRestClient, RestClient communicationRestClient) {
		this.ticket = ticketRestClient;
		this.billing = billingRestClient;
		this.communication = communicationRestClient;
	}

	@McpTool(description = "Get verified billing transactions for a customer. Read-only.")
	public Object getBillingTransactions(@McpToolParam(description = "Customer identifier") String customerId) {
		return billing.get().uri("/api/billing/customers/{customerId}/transactions", customerId).retrieve()
				.body(Object.class);
	}

	@McpTool(description = "Check whether a customer subscription has multiple successful charges. Read-only.")
	public Object checkDuplicatePayment(@McpToolParam(description = "Customer identifier") String customerId,
			@McpToolParam(description = "Subscription identifier") String subscriptionId) {
		return billing.get().uri("/api/billing/customers/{customerId}/subscriptions/{subscriptionId}/duplicate-check",
				customerId, subscriptionId).retrieve().body(Object.class);
	}

	@McpTool(description = "Create a refund request for billing-team review. This does not transfer money.")
	public Object createRefundRequest(@McpToolParam(description = "Customer identifier") String customerId,
			@McpToolParam(description = "Comma-separated verified transaction identifiers") String transactionIds,
			@McpToolParam(description = "Reason for refund review") String reason) {
		return billing.post().uri("/api/billing/refund-requests")
				.body(Map.of("customerId", customerId, "transactionIds", transactionIds, "reason", reason)).retrieve()
				.body(Object.class);
	}

	@McpTool(description = "Retrieve a support ticket by its identifier.")
	public Object getTicket(@McpToolParam(description = "Ticket identifier") String ticketId) {
		return ticket.get().uri("/api/tickets/{ticketId}", ticketId).retrieve().body(Object.class);
	}

	@McpTool(description = "Send a customer notification through the communication service.")
	public Object sendCustomerNotification(@McpToolParam(description = "Customer identifier") String customerId,
			@McpToolParam(description = "Channel such as EMAIL or SMS") String channel,
			@McpToolParam(description = "Notification subject") String subject,
			@McpToolParam(description = "Notification message") String message,
			@McpToolParam(description = "Ticket identifier") String ticketId) {
		return communication.post().uri("/api/communications/send").body(Map.of("customerId", customerId, "channel",
				channel, "subject", subject, "message", message, "ticketId", ticketId)).retrieve().body(Object.class);
	}
}

package com.example.support.knowledge;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KnowledgeSeeder {
	@Bean
	CommandLineRunner seedKnowledge(KnowledgeRepository repo) {
		return args -> {
			if (repo.count() == 0) {
				repo.save(new KnowledgeArticle("KB-101", "Duplicate payment policy", "BILLING",
						"When two successful charges exist for the same customer and subscription, verify both transaction IDs and amounts. Create a refund request for billing review. Do not promise a refund until Billing confirms completion.",
						"3"));
				repo.save(new KnowledgeArticle("KB-115", "Refund processing", "BILLING",
						"Refund requests are reviewed by the billing team. A request in PENDING_REVIEW is not a completed refund. The customer should receive a status update after review.",
						"2"));
				repo.save(new KnowledgeArticle("KB-120", "Subscription activation troubleshooting", "SUBSCRIPTION",
						"If payment is successful but the subscription is inactive, verify the subscription state and escalate to subscription operations. Do not reactivate an account without an authoritative billing/subscription result.",
						"1"));
				repo.save(new KnowledgeArticle("KB-130", "Business customer escalation", "SUPPORT",
						"Business customers reporting production impact should be reviewed promptly by the support team. Priority must follow the approved incident policy and verified impact.",
						"1"));
			}
		};
	}
}

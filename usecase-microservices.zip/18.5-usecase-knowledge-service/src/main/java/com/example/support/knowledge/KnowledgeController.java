package com.example.support.knowledge;

import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.*;

@RestController
@RequestMapping("/api/knowledge")
public class KnowledgeController {
	private final KnowledgeRepository repo;

	public KnowledgeController(KnowledgeRepository r) {
		repo = r;
	}

	public record RetrieveRequest(String query, Integer topK) {
	}

	public record KnowledgeDocument(String sourceId, String title, String category, String content, String version) {
	}

	public record RetrieveResponse(String query, List<KnowledgeDocument> documents) {
	}

	@PostMapping("/retrieve")
	public RetrieveResponse retrieve(@RequestBody RetrieveRequest request) {
		String q = request.query() == null ? "" : request.query().toLowerCase(Locale.ROOT);
		Set<String> terms = Arrays.stream(q.split("[^a-z0-9]+")).filter(s -> s.length() > 2)
				.collect(Collectors.toSet());
		int limit = Math.max(1, Math.min(request.topK() == null ? 3 : request.topK(), 10));
		List<KnowledgeDocument> docs = repo.findByActiveTrue().stream().map(a -> Map.entry(a, score(a, terms)))
				.filter(e -> e.getValue() > 0)
				.sorted(Map.Entry.<KnowledgeArticle, Integer>comparingByValue().reversed()).limit(limit)
				.map(e -> new KnowledgeDocument(e.getKey().getId(), e.getKey().getTitle(), e.getKey().getCategory(),
						e.getKey().getContent(), e.getKey().getVersion()))
				.toList();
		return new RetrieveResponse(request.query(), docs);
	}

	private int score(KnowledgeArticle a, Set<String> terms) {
		String text = (a.getTitle() + " " + a.getCategory() + " " + a.getContent()).toLowerCase(Locale.ROOT);
		int score = 0;
		for (String term : terms)
			if (text.contains(term))
				score++;
		return score;
	}

	@GetMapping("/articles")
	public List<KnowledgeArticle> articles() {
		return repo.findByActiveTrue();
	}
}

package com.example.support.knowledge;

import jakarta.persistence.*;

@Entity
@Table(name = "knowledge_articles")
public class KnowledgeArticle {
	@Id
	private String id;
	private String title;
	private String category;
	@Column(length = 8000)
	private String content;
	private boolean active = true;
	private String version;

	protected KnowledgeArticle() {
	}

	public KnowledgeArticle(String id, String title, String category, String content, String version) {
		this.id = id;
		this.title = title;
		this.category = category;
		this.content = content;
		this.version = version;
		this.active = true;
	}

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getCategory() {
		return category;
	}

	public String getContent() {
		return content;
	}

	public boolean isActive() {
		return active;
	}

	public String getVersion() {
		return version;
	}
}

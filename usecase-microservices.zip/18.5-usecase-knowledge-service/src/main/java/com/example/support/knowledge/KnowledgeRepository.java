package com.example.support.knowledge;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface KnowledgeRepository extends JpaRepository<KnowledgeArticle, String> {
	List<KnowledgeArticle> findByActiveTrue();
}

package com.example.support.billing;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BillingDataInitializer {
	@Bean
	CommandLineRunner seedBilling(TransactionRepository repo) {
		return args -> {
			if (repo.count() == 0) {
				repo.save(new Transaction("TX101", "C1001", "SUB1001", 500000, "INR", "SUCCESS"));
				repo.save(new Transaction("TX102", "C1001", "SUB1001", 500000, "INR", "SUCCESS"));
				repo.save(new Transaction("TX201", "C2001", "SUB2001", 199900, "INR", "SUCCESS"));
			}
		};
	}
}

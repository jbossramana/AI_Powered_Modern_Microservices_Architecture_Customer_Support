package com.example.support.billing;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, String> {
	List<Transaction> findByCustomerIdAndSubscriptionId(String customerId, String subscriptionId);

	List<Transaction> findByCustomerId(String customerId);
}

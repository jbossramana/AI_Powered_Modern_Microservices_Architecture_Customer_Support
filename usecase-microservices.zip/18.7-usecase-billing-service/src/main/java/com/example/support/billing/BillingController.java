package com.example.support.billing;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/billing")
public class BillingController {
	private final TransactionRepository transactions;
	private final RefundRequestRepository refunds;

	public BillingController(TransactionRepository t, RefundRequestRepository r) {
		transactions = t;
		refunds = r;
	}

	@GetMapping("/customers/{customerId}/transactions")
	public List<Transaction> transactions(@PathVariable String customerId) {
		return transactions.findByCustomerId(customerId);
	}

	@GetMapping("/customers/{customerId}/subscriptions/{subscriptionId}/duplicate-check")
	public Map<String, Object> duplicate(@PathVariable String customerId, @PathVariable String subscriptionId) {
		List<Transaction> rows = transactions.findByCustomerIdAndSubscriptionId(customerId, subscriptionId).stream()
				.filter(t -> "SUCCESS".equalsIgnoreCase(t.getStatus())).toList();
		boolean duplicate = rows.size() > 1;
		return Map.of("customerId", customerId, "subscriptionId", subscriptionId, "possibleDuplicate", duplicate,
				"successfulTransactionCount", rows.size(), "transactions", rows);
	}

	public record RefundRequestDto(@NotBlank String customerId, @NotBlank String transactionIds,
			@NotBlank String reason) {
	}

	@PostMapping("/refund-requests")
	@ResponseStatus(HttpStatus.CREATED)
	public RefundRequest requestRefund(@Valid @RequestBody RefundRequestDto r) {
		// Demo only: record a request for human review. No money is transferred.
		return refunds.save(new RefundRequest(r.customerId(), r.transactionIds(), r.reason()));
	}
}

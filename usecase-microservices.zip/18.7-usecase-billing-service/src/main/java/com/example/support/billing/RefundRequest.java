package com.example.support.billing;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "refund_requests")
public class RefundRequest {
	@Id
	private String id = UUID.randomUUID().toString();
	private String customerId;
	@Column(length = 2000)
	private String transactionIds;
	private String reason;
	private String status = "PENDING_REVIEW";
	private Instant createdAt = Instant.now();

	protected RefundRequest() {
	}

	public RefundRequest(String c, String ids, String reason) {
		this.customerId = c;
		this.transactionIds = ids;
		this.reason = reason;
	}

	public String getId() {
		return id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getTransactionIds() {
		return transactionIds;
	}

	public String getReason() {
		return reason;
	}

	public String getStatus() {
		return status;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}
}

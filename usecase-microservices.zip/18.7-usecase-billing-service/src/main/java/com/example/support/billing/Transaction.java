package com.example.support.billing;

import jakarta.persistence.*;

@Entity
@Table(name = "billing_transactions")
public class Transaction {
	@Id
	private String transactionId;
	private String customerId;
	private String subscriptionId;
	private long amountInPaise;
	private String currency;
	private String status;

	protected Transaction() {
	}

	public Transaction(String id, String customer, String subscription, long amount, String currency, String status) {
		this.transactionId = id;
		this.customerId = customer;
		this.subscriptionId = subscription;
		this.amountInPaise = amount;
		this.currency = currency;
		this.status = status;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getSubscriptionId() {
		return subscriptionId;
	}

	public long getAmountInPaise() {
		return amountInPaise;
	}

	public String getCurrency() {
		return currency;
	}

	public String getStatus() {
		return status;
	}
}

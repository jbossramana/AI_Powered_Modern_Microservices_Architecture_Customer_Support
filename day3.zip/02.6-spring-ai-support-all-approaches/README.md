# Spring AI Customer Support — All Approaches

A Java 21 / Spring Boot application demonstrating Java-controlled workflows, LLM tool selection, automatic and manual tool-calling loops, hybrid orchestration, and sequential multi-agent processing.

## 1. Technology stack

- Java 21
- Spring Boot 4.1.0
- Spring AI 2.0.2
- Ollama with `llama3.2:latest`
- Maven 3.9+

## 2. Project approaches and REST endpoints

Base URL: `http://localhost:8080`

| # | Approach | Decision maker | Execution | Endpoint |
|---:|---|---|---|---|
| 1 | No agent — one operation | Java | Java | `POST /api/workflows/no-agent/single-tool` |
| 2 | No agent — multiple operations | Java | Java | `POST /api/workflows/no-agent/multiple-tools` |
| 3 | Java lookup + LLM explanation | Java selects lookup | Java lookup, LLM explains | `POST /api/workflows/no-agent/single-tool-llm` |
| 4 | Java lookups + LLM summary | Java selects lookups | Java lookups, LLM summarizes | `POST /api/workflows/no-agent/multiple-tools-llm` |
| 5 | Agent — one tool | LLM | Spring AI automatic tool loop | `POST /api/workflows/agent/single-tool` |
| 6 | Agent — multiple tools | LLM | Spring AI automatic tool loop | `POST /api/workflows/agent/multiple-tools` |
| 7 | Agentic manual loop | LLM selects tools | Java `ToolCallingManager` loop | `POST /api/workflows/agentic/manual-loop` |
| 8 | Hybrid | Java mandatory checks; LLM may select additional tools | Java + Spring AI | `POST /api/workflows/hybrid` |
| 9 | Sequential multi-agent | Specialist LLM stages | Java orchestrates stages | `POST /api/workflows/multi-agent` |

## 3. Architecture overview

```text
                         REST Controller
                                |
                         WorkflowService
                                |
       +------------------------+-------------------------+
       |                        |                         |
   Java-owned flow          ChatClient flow            Hybrid flow
   (no agent)               (LLM selects tools)        (Java + LLM)
       |                        |                         |
 SupportDataService        SupportTools (@Tool)       Mandatory Java checks
       |                        |                         |
       +------------------------+-------------------------+
                                |
                           Ollama LLM
                                |
                  Spring AI / ToolCallingManager
```

The LLM does not directly execute Java methods. It returns structured tool-call requests. Spring AI/Java resolves the registered callback, executes the Java method, and returns the result to the model.

## 4. Demo data and safety notes

### Customer plans

| Customer ID | Plan |
|---|---|
| `C-1001` | Pro |
| `C-1002` | Business |
| Other IDs | Standard |

### Tickets

| Ticket ID | Status | Category |
|---|---|---|
| `TCK-1001` | OPEN | BILLING |
| `TCK-1002` | IN_PROGRESS | LOGIN |
| `TCK-1003` | RESOLVED | DELIVERY |

For `C-1001` + `TCK-1001`, the demo payment lookup returns a static note that two matching entries are flagged for verification. This is **not** a transaction-matching algorithm and is not proof of a duplicate charge or refund eligibility.

The refund tool is deliberately non-operational: it neither persists a request nor issues money. A production implementation needs authenticated authorization, authoritative payment checks, idempotency, audit logging, and explicit approval.

## 5. Windows setup — Command Prompt (CMD)

The commands in this section are for **Windows Command Prompt (`cmd.exe`)**. They are not PowerShell commands. Open CMD and run the following commands.

### 5.1 Verify Java and Maven

```cmd
java -version
mvn -version
```

Use JDK 21 and Maven 3.9 or later.

### 5.2 Download and verify the Ollama model

```cmd
ollama pull llama3.2:latest
ollama list
```

Ollama normally runs as a Windows background/desktop service. Check that its local API responds:

```cmd
curl.exe http://localhost:11434/api/tags
```

If Ollama is not already running, start it in a separate CMD window:

```cmd
ollama serve
```

Do not start another Ollama server if one is already listening on port `11434`.

### 5.3 Build and start the Spring Boot application

Open CMD in the extracted project directory (the directory containing `pom.xml`):

```cmd
mvn clean test
mvn clean spring-boot:run
```

Keep this CMD window open. Open a **second CMD window** for the HTTP tests below.

The application base URL is `http://localhost:8080`.

To stop the application, press `Ctrl+C` in the application CMD window.

## 6. Windows CMD — all curl.exe commands

**Important:** Every POST command below is a single line for Windows Command Prompt. Use `curl.exe` explicitly. The backslashes before JSON quotation marks (`\"`) are required so CMD passes valid JSON to the application.

### Test 0 — Spring Boot health check

```cmd
curl.exe -i http://localhost:8080/actuator/health
```

### Test 1 — No agent: Java invokes one operation

Java directly retrieves the customer's plan. No LLM tool selection is involved.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/no-agent/single-tool" -H "Content-Type: application/json" -d "{\"question\":\"Find the support plan for this customer\",\"customerId\":\"C-1001\"}"
```

### Test 2 — No agent: Java invokes multiple operations

Java retrieves ticket status, customer plan, category, and support policy in a fixed sequence.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/no-agent/multiple-tools" -H "Content-Type: application/json" -d "{\"question\":\"Check the ticket and customer support details\",\"ticketId\":\"TCK-1001\",\"customerId\":\"C-1001\"}"
```

### Test 3 — Java lookup + LLM explanation

Java retrieves the plan. The LLM explains the supplied value; it does not choose or execute a tool.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/no-agent/single-tool-llm" -H "Content-Type: application/json" -d "{\"question\":\"Explain the support plan in simple terms\",\"customerId\":\"C-1001\"}"
```

### Test 4 — Java lookups + LLM summary

Java retrieves the ticket and customer facts. The LLM summarizes those facts.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/no-agent/multiple-tools-llm" -H "Content-Type: application/json" -d "{\"question\":\"Summarize the ticket status, customer plan and applicable policy\",\"ticketId\":\"TCK-1001\",\"customerId\":\"C-1001\"}"
```

### Test 5 — Agent: one tool exposed

Only the customer-plan lookup tool is exposed to the LLM. Spring AI manages the tool-call continuation automatically.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/agent/single-tool" -H "Content-Type: application/json" -d "{\"question\":\"What support plan does customer C-1001 have? Use the customer plan lookup.\"}"
```

### Test 6 — Agent: multiple tools exposed

The LLM can choose among the available support tools. Spring AI manages the automatic tool-calling loop.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/agent/multiple-tools" -H "Content-Type: application/json" -d "{\"question\":\"Investigate billing ticket TCK-1001 for customer C-1001. Check status, plan, policy, order and payment information. Explain verified facts and pending checks.\"}"
```

### Test 7 — Agentic AI: manual Java-controlled tool loop

The LLM selects tools, while Java explicitly controls each iteration using `ToolCallingManager`. The implementation has a six-iteration safety limit.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/agentic/manual-loop" -H "Content-Type: application/json" -d "{\"question\":\"Investigate ticket TCK-1001 for customer C-1001. Use relevant tools and summarize the verified facts and remaining checks.\"}"
```

Inspect the response fields such as `iterations`, `totalToolCalls`, `loopLog`, and `answer`.

### Test 8 — Hybrid: Java mandatory checks + LLM additional tool selection

Java always retrieves the ticket status, customer plan, category, and policy. For a billing/payment goal, Java also retrieves the demo payment and order details. The LLM can then select additional available tools and explain the result.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/hybrid" -H "Content-Type: application/json" -d "{\"question\":\"Investigate possible duplicate payment\",\"goal\":\"Investigate possible duplicate payment and explain next steps\",\"ticketId\":\"TCK-1001\",\"customerId\":\"C-1001\"}"
```

### Test 9 — Sequential multi-agent workflow

The service runs three specialist LLM stages in sequence: triage, investigation, and customer response. Java controls the sequence and passes each stage's result to the next.

```cmd
curl.exe -X POST "http://localhost:8080/api/workflows/multi-agent" -H "Content-Type: application/json" -d "{\"question\":\"The customer says they were charged twice and wants a refund. Investigate the issue and prepare a response.\",\"ticketId\":\"TCK-1001\",\"customerId\":\"C-1001\"}"
```

## 7. Additional CMD checks

### Check Ollama is reachable

```cmd
curl.exe -i http://localhost:11434/api/tags
```

### List locally available models

```cmd
ollama list
```

### Run tests without starting the application

```cmd
mvn clean test
```

### Package the application

```cmd
mvn clean package
```

### Run the packaged JAR

```cmd
java -jar target/spring-ai-support-all-approaches-1.0.0.jar
```

## 8. Important classes

- `SupportDataService`: deterministic demo business/data operations.
- `SupportTools`: Java methods annotated with `@Tool` and exposed to the LLM.
- `WorkflowController`: REST endpoints for each approach.
- `WorkflowRequest`: request DTO. The `question` field is required by validation.
- `WorkflowService`: implements the workflow and agentic patterns.
- `agentMultipleTools`: uses `.tools(tools)` and Spring AI's automatic tool-calling loop.
- `agenticManualLoop`: explicitly controls tool iterations using `ToolCallingManager.executeToolCalls(...)`.
- `hybrid`: performs mandatory Java checks first; the LLM may select additional tools.
- `multiAgent`: sequential triage → investigation → customer response.

## 9. Troubleshooting

- **Connection refused on port 8080:** confirm that Spring Boot started successfully and that the application terminal is still running.
- **Connection refused on port 11434:** start the Ollama application or run `ollama serve` in a separate CMD window.
- **Model not found:** run `ollama pull llama3.2:latest`, then verify with `ollama list`.
- **LLM call fails:** check the Spring Boot console for Ollama connectivity, model-loading, and timeout errors.
- **No tool call is selected:** use a model with tool-calling support and ask a question that requires data available only through the tools. Model behavior can vary.
- **HTTP 400 / validation error:** ensure the JSON is valid and includes the required nonblank `question` field. The Java-only endpoints also accept `question` because the shared request DTO validates it.

## 10. Production recommendations

1. Authenticate the caller and validate customer/ticket ownership in Java.
2. Perform mandatory checks and enforce business invariants in Java.
3. Expose only least-privilege tools to the LLM.
4. Re-check authorization and validate arguments when each tool executes.
5. Separate read-only tools from state-changing tools.
6. Require approval, idempotency, and audit logging for refunds/payments.
7. Add timeouts, iteration limits, token budgets, rate limits, and observability.

## 11. Scope and limitations

This is a teaching application, not a production payment system:

- Data is in-memory and resets when the application restarts.
- There is no database, authentication, authorization, or real payment gateway.
- The multi-agent workflow is sequential specialist prompting, not parallel/distributed orchestration.
- The duplicate-payment indicator is static demo text, not real transaction comparison.
- The refund method does not persist a request or issue a refund.
- LLM output is probabilistic and must be validated before business use.

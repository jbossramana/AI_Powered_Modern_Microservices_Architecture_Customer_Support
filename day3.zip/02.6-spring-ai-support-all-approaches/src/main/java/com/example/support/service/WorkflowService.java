
package com.example.support.service;

import com.example.support.domain.SupportDataService;
import com.example.support.tools.SupportTools;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.model.tool.ToolCallingManager;
import org.springframework.ai.model.tool.ToolCallingChatOptions;
import org.springframework.ai.model.tool.ToolExecutionResult;
import org.springframework.ai.support.ToolCallbacks;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class WorkflowService {

	private static final String SYSTEM_PROMPT = """
			You are an enterprise customer-support assistant.

			Use only facts supplied by the application or returned by tools.
			Never invent ticket, customer, payment or order information.

			A possible duplicate-payment indicator is not proof of a duplicate charge.
			Never claim a refund was approved, submitted or paid unless an
			authoritative system confirms it.

			Be concise, professional and explain what is verified versus pending.
			""";

	private final SupportDataService data;
	private final SupportTools tools;
	private final ChatClient chatClient;
	private final ChatModel chatModel;
	private final ToolCallingManager toolCallingManager;

	public WorkflowService(SupportDataService data, SupportTools tools, ChatClient.Builder chatClientBuilder,
			ChatModel chatModel, ToolCallingManager toolCallingManager) {

		this.data = data;
		this.tools = tools;
		this.chatModel = chatModel;
		this.toolCallingManager = toolCallingManager;

		this.chatClient = chatClientBuilder.defaultSystem(SYSTEM_PROMPT).build();
	}

	// ============================================================
	// APPROACH 1: NO AGENT - SINGLE JAVA OPERATION
	// Java selects and executes the operation.
	// ============================================================

	public Map<String, Object> noAgentSingleTool(String customerId) {

		String plan = data.getCustomerPlan(customerId);

		return map("approach", "NO_AGENT_SINGLE_TOOL", "executionOwner", "JAVA", "customerId", customerId,
				"customerPlan", plan);
	}

	// ============================================================
	// APPROACH 2: NO AGENT - MULTIPLE JAVA OPERATIONS
	// Java controls the sequence.
	// ============================================================

	public Map<String, Object> noAgentMultipleTools(String ticketId, String customerId) {

		String status = data.getTicketStatus(ticketId);
		String plan = data.getCustomerPlan(customerId);
		String category = data.getTicketCategory(ticketId);
		String policy = data.getSupportPolicy(plan, category);

		return map("approach", "NO_AGENT_MULTIPLE_TOOLS", "executionOwner", "JAVA", "ticketId", ticketId, "customerId",
				customerId, "ticketStatus", status, "customerPlan", plan, "category", category, "policy", policy);
	}

	// ============================================================
	// APPROACH 3: JAVA TOOL + LLM EXPLANATION
	// Java fetches data. LLM explains it.
	// No LLM tool calling.
	// ============================================================

	public Map<String, Object> noAgentSingleToolWithLlm(String customerId) {

		String plan = data.getCustomerPlan(customerId);

		String answer = chatClient.prompt().system("""
				Explain the supplied customer plan.
				Do not call tools or invent benefits.
				""").user("Customer ID: " + customerId + "\nVerified plan: " + plan).call().content();

		return map("approach", "NO_AGENT_SINGLE_TOOL_WITH_LLM", "javaRetrieved", plan, "llmResponse", answer);
	}

	// ============================================================
	// APPROACH 4: MULTIPLE JAVA OPERATIONS + LLM SUMMARY
	// Java fetches facts. LLM summarizes them.
	// ============================================================

	public Map<String, Object> noAgentMultipleToolsWithLlm(String ticketId, String customerId) {

		Map<String, Object> facts = noAgentMultipleTools(ticketId, customerId);

		String answer = chatClient.prompt().system("""
				Summarize these verified support facts.
				Do not call tools or add facts.
				""").user("Verified facts: " + facts).call().content();

		return map("approach", "NO_AGENT_MULTIPLE_TOOLS_WITH_LLM", "verifiedFacts", facts, "llmResponse", answer);
	}

	// ============================================================
	// APPROACH 5A: AGENT - SINGLE TOOL
	// LLM selects the tool.
	// Spring AI executes the tool-calling loop automatically.
	// ============================================================

	public Map<String, Object> agentSingleTool(String question) {

		String answer = chatClient.prompt().system("""
				You can use only the customer-plan lookup tool.
				Use it when the question requires customer plan information.
				Answer using the tool result.
				""").user(question).tools(new CustomerPlanOnlyTool(tools)).call().content();

		return map("approach", "AGENT_SINGLE_TOOL_AUTOMATIC", "toolSelection", "LLM", "toolExecution",
				"SPRING_AI_AUTOMATIC_LOOP", "answer", answer);
	}

	// ============================================================
	// APPROACH 5B: AGENT - MULTIPLE TOOLS
	// LLM selects from available tools.
	// Spring AI executes the loop automatically.
	// ============================================================

	public Map<String, Object> agentMultipleTools(String question) {

		String answer = chatClient.prompt().system("""
				You are a customer-support investigation agent.

				Use available tools when necessary.
				You may call multiple tools.
				Verify facts before answering.
				""").user(question).tools(tools).call().content();

		return map("approach", "AGENT_MULTIPLE_TOOLS_AUTOMATIC", "toolSelection", "LLM", "toolExecution",
				"SPRING_AI_AUTOMATIC_LOOP", "answer", answer);
	}

	// ============================================================
	// APPROACH 6: AGENTIC - MANUAL TOOL-CALLING LOOP
	//
	// LLM decides which tools to call.
	// Java controls every iteration.
	// ChatModel returns tool-call requests.
	// ToolCallingManager executes requested tools.
	//
	// Uses ChatModel.call(Prompt), not ChatClient.options().
	// ============================================================

	public Map<String, Object> agenticManualLoop(String question) {

		// 1. Convert Spring bean methods into ToolCallbacks.
		ToolCallback[] callbacks = ToolCallbacks.from(tools);

		// 2. Configure tool-calling options.
		ToolCallingChatOptions chatOptions = ToolCallingChatOptions.builder().toolCallbacks(callbacks).build();

		// 3. Create initial conversation.
		List<Message> messages = new ArrayList<>();

		messages.add(new SystemMessage(SYSTEM_PROMPT));
		messages.add(new UserMessage(question));

		// 4. Create initial Prompt with tool options.
		Prompt prompt = new Prompt(messages, chatOptions);

		// 5. Invoke LLM directly.
		ChatResponse response = chatModel.call(prompt);

		int iterations = 0;
		int totalToolCalls = 0;

		List<String> loopLog = new ArrayList<>();
		List<String> selectedTools = new ArrayList<>();

		// 6. Java controls the agentic loop.
		while (response != null && response.hasToolCalls() && iterations < 6) {

			iterations++;

			// Count requested tool calls.
			int currentToolCalls = response.getResults().stream()
					.mapToInt(result -> result.getOutput().getToolCalls().size()).sum();

			totalToolCalls += currentToolCalls;

			// IMPORTANT:
			// Use ordinary for loops here.
			// iterations is mutable and cannot be captured
			// by a lambda expression.

			for (var result : response.getResults()) {

				for (var toolCall : result.getOutput().getToolCalls()) {

					String toolName = toolCall.name();

					selectedTools.add(toolName);

					loopLog.add("Iteration " + iterations + ": LLM selected tool " + toolName);
				}
			}

			// 7. Java executes tool calls.
			ToolExecutionResult executionResult = toolCallingManager.executeToolCalls(prompt, response);

			// 8. Update conversation history.
			prompt = new Prompt(executionResult.conversationHistory(), chatOptions);

			// 9. Send updated conversation back to LLM.
			response = chatModel.call(prompt);
		}

		// 10. Extract final LLM response.
		String answer = "No response received from the model.";

		if (response != null && response.getResult() != null && response.getResult().getOutput() != null) {

			answer = response.getResult().getOutput().getText();
		}

		// Safety limit.
		if (iterations >= 6 && response != null && response.hasToolCalls()) {

			answer += "\nExecution stopped at the six-iteration safety limit.";
		}

		return map("approach", "AGENTIC_MANUAL_TOOL_LOOP", "toolSelection", "LLM", "loopControl", "JAVA",
				"toolExecution", "ToolCallingManager", "iterations", iterations, "totalToolCalls", totalToolCalls,
				"selectedTools", selectedTools, "loopLog", loopLog, "answer", answer);
	}

	// ============================================================
	// APPROACH 7: HYBRID AGENTIC
	//
	// Java performs mandatory business checks.
	// LLM reasons over facts and can select additional tools.
	// ============================================================

	public Map<String, Object> hybrid(String goal, String ticketId, String customerId) {

		// Mandatory Java operations.
		String status = data.getTicketStatus(ticketId);
		String plan = data.getCustomerPlan(customerId);
		String category = data.getTicketCategory(ticketId);
		String policy = data.getSupportPolicy(plan, category);

		Map<String, Object> mandatoryFacts = new LinkedHashMap<>();

		mandatoryFacts.put("ticketStatus", status);
		mandatoryFacts.put("customerPlan", plan);
		mandatoryFacts.put("category", category);
		mandatoryFacts.put("policy", policy);

		// Payment investigation for billing-related requests.
		boolean paymentGoal = isPaymentGoal(goal) || "BILLING".equalsIgnoreCase(category);

		if (paymentGoal) {

			mandatoryFacts.put("paymentInvestigation", data.getPaymentDetails(customerId, ticketId));

			mandatoryFacts.put("orderDetails", data.getOrderDetails(customerId, ticketId));
		}

		// LLM can select additional tools if useful.
		String answer = chatClient.prompt().system("""
				You are the reasoning component in a hybrid support workflow.

				Java has already performed mandatory checks.
				Use the supplied verified facts.

				You may call additional tools when useful.
				Do not repeat mandatory checks unnecessarily.

				Distinguish possible duplicate-payment indicators
				from confirmed duplicate payments.

				Do not approve or promise refunds.
				""").user("Goal: " + goal + "\nTicket ID: " + ticketId + "\nCustomer ID: " + customerId
				+ "\nMandatory Java facts: " + mandatoryFacts).tools(tools).call().content();

		return map("approach", "HYBRID_JAVA_MANDATORY_LLM_ADDITIONAL", "mandatoryJavaFacts", mandatoryFacts,
				"paymentInvestigationRequired", paymentGoal, "llmAnalysis", answer, "refundApproved", false,
				"refundSubmitted", false);
	}

	// ============================================================
	// APPROACH 8: MULTI-AGENT
	//
	// Triage Agent
	// |
	// Investigation Agent
	// |
	// Response Agent
	//
	// Sequential specialist-agent orchestration.
	// ============================================================

	public Map<String, Object> multiAgent(String message, String ticketId, String customerId) {

		// Agent 1: Triage.
		String triage = chatClient.prompt().system("""
				You are the Triage Agent.

				Classify the customer request.
				Identify issue category and urgency.
				Use only the supplied information.
				""").user("Request: " + message + "\nTicket: " + ticketId + "\nCustomer: " + customerId).call()
				.content();

		// Agent 2: Investigation.
		String investigation = chatClient.prompt().system("""
				You are the Investigation Agent.

				Verify ticket, customer plan, policy,
				and relevant payment/order information.

				Use the available tools.
				Do not approve or issue refunds.
				""").user("Original request: " + message + "\nTriage result: " + triage + "\nTicket: " + ticketId
				+ "\nCustomer: " + customerId).tools(tools).call().content();

		// Agent 3: Customer response.
		String finalResponse = chatClient.prompt().system("""
				You are the Customer Response Agent.

				Prepare a professional customer response
				using only the triage and investigation results.

				Explain verified facts and pending checks.
				Never claim that a refund was submitted or approved
				unless the evidence confirms it.
				""").user("Original request: " + message + "\nTriage: " + triage + "\nInvestigation: " + investigation)
				.call().content();

		return map("approach", "SEQUENTIAL_MULTI_AGENT", "triageAgent", triage, "investigationAgent", investigation,
				"responseAgent", finalResponse);
	}

	// ============================================================
	// HELPER METHODS
	// ============================================================

	private boolean isPaymentGoal(String goal) {

		String value = goal.toLowerCase(Locale.ROOT);

		return value.contains("payment") || value.contains("duplicate") || value.contains("transaction")
				|| value.contains("billing") || value.contains("refund") || value.contains("charge");
	}

	private static Map<String, Object> map(Object... pairs) {

		Map<String, Object> result = new LinkedHashMap<>();

		for (int i = 0; i < pairs.length; i += 2) {

			result.put(String.valueOf(pairs[i]), pairs[i + 1]);
		}

		return result;
	}

	// Wrapper exposing only one tool for the single-tool agent example.
	static class CustomerPlanOnlyTool {

		private final SupportTools delegate;

		CustomerPlanOnlyTool(SupportTools delegate) {
			this.delegate = delegate;
		}

		@Tool(description = "Look up the support plan for a customer using the customer ID.")
		public String getCustomerPlan(String customerId) {
			return delegate.getCustomerPlan(customerId);
		}
	}
}

package com.example.support.tools;

import com.example.support.domain.SupportDataService;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

@Component
public class SupportTools {
	private final SupportDataService data;

	public SupportTools(SupportDataService data) {
		this.data = data;
	}

	@Tool(description = "Look up the current status of a support ticket using its ticket ID.")
	public String getTicketStatus(String ticketId) {
		return data.getTicketStatus(ticketId);
	}

	@Tool(description = "Look up the support plan for a customer using the customer ID.")
	public String getCustomerPlan(String customerId) {
		return data.getCustomerPlan(customerId);
	}

	@Tool(description = "Retrieve the category of a support ticket using its ticket ID.")
	public String getTicketCategory(String ticketId) {
		return data.getTicketCategory(ticketId);
	}

	@Tool(description = "Retrieve support policy for a customer's plan and issue category.")
	public String getSupportPolicy(String plan, String category) {
		return data.getSupportPolicy(plan, category);
	}

	@Tool(description = "Retrieve payment investigation notes. This is not proof of duplicate payment or refund eligibility.")
	public String getPaymentDetails(String customerId, String ticketId) {
		return data.getPaymentDetails(customerId, ticketId);
	}

	@Tool(description = "Retrieve order details for a customer and support ticket.")
	public String getOrderDetails(String customerId, String ticketId) {
		return data.getOrderDetails(customerId, ticketId);
	}

	@Tool(description = "Demo refund-request operation. It intentionally does not submit a real request or issue money.")
	public String createRefundRequest(String customerId, String ticketId, String reason) {
		return data.createRefundRequest(customerId, ticketId, reason);
	}
}

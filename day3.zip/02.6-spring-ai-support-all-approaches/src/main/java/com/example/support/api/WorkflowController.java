package com.example.support.api;

import com.example.support.service.WorkflowService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/workflows")
public class WorkflowController {
	private final WorkflowService service;

	public WorkflowController(WorkflowService service) {
		this.service = service;
	}

	@PostMapping("/no-agent/single-tool")
	public Map<String, Object> noAgentSingle(@RequestBody @Valid WorkflowRequest r) {
		return service.noAgentSingleTool(req(r.customerId(), "customerId"));
	}

	@PostMapping("/no-agent/multiple-tools")
	public Map<String, Object> noAgentMultiple(@RequestBody @Valid WorkflowRequest r) {
		return service.noAgentMultipleTools(req(r.ticketId(), "ticketId"), req(r.customerId(), "customerId"));
	}

	@PostMapping("/no-agent/single-tool-llm")
	public Map<String, Object> noAgentSingleLlm(@RequestBody @Valid WorkflowRequest r) {
		return service.noAgentSingleToolWithLlm(req(r.customerId(), "customerId"));
	}

	@PostMapping("/no-agent/multiple-tools-llm")
	public Map<String, Object> noAgentMultipleLlm(@RequestBody @Valid WorkflowRequest r) {
		return service.noAgentMultipleToolsWithLlm(req(r.ticketId(), "ticketId"), req(r.customerId(), "customerId"));
	}

	@PostMapping("/agent/single-tool")
	public Map<String, Object> agentSingle(@RequestBody @Valid WorkflowRequest r) {
		return service.agentSingleTool(req(r.question(), "question"));
	}

	@PostMapping("/agent/multiple-tools")
	public Map<String, Object> agentMultiple(@RequestBody @Valid WorkflowRequest r) {
		return service.agentMultipleTools(req(r.question(), "question"));
	}

	@PostMapping("/agentic/manual-loop")
	public Map<String, Object> agentic(@RequestBody @Valid WorkflowRequest r) {
		return service.agenticManualLoop(req(r.question(), "question"));
	}

	@PostMapping("/hybrid")
	public Map<String, Object> hybrid(@RequestBody @Valid WorkflowRequest r) {
		String goal = r.goal() == null || r.goal().isBlank() ? r.question() : r.goal();
		return service.hybrid(req(goal, "goal"), req(r.ticketId(), "ticketId"), req(r.customerId(), "customerId"));
	}

	@PostMapping("/multi-agent")
	public Map<String, Object> multiAgent(@RequestBody @Valid WorkflowRequest r) {
		return service.multiAgent(req(r.question(), "question"), req(r.ticketId(), "ticketId"),
				req(r.customerId(), "customerId"));
	}

	private String req(String v, String field) {
		if (v == null || v.isBlank())
			throw new IllegalArgumentException("Request field '" + field + "' is required.");
		return v;
	}
}

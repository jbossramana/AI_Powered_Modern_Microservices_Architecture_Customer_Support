package com.example.support.api;

import jakarta.validation.constraints.NotBlank;

public record WorkflowRequest(@NotBlank String question, String ticketId, String customerId, String goal) {
}

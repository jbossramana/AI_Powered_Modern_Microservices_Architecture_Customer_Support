package com.example.hierarchicalrag.dto;

public record QueryRequest(String question) {
}

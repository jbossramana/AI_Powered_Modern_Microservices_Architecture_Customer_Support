package com.example.hierarchicalrag.controller;

import com.example.hierarchicalrag.dto.QueryRequest;
import com.example.hierarchicalrag.dto.QueryResponse;
import com.example.hierarchicalrag.service.DocumentIngestionService;
import com.example.hierarchicalrag.service.HierarchicalRetrievalService;
import com.example.hierarchicalrag.service.ParentDocumentStore;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RagController {

    private final DocumentIngestionService ingestionService;
    private final HierarchicalRetrievalService retrievalService;
    private final ParentDocumentStore parentStore;

    public RagController(
            DocumentIngestionService ingestionService,
            HierarchicalRetrievalService retrievalService,
            ParentDocumentStore parentStore) {
        this.ingestionService = ingestionService;
        this.retrievalService = retrievalService;
        this.parentStore = parentStore;
    }

    @PostMapping(
            value = "/documents/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> uploadPdf(
            @RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("Please upload a non-empty PDF");
        }

        String filename = file.getOriginalFilename() == null
                ? "uploaded-document.pdf" : file.getOriginalFilename();

        int chunks = ingestionService.ingestPdf(file.getBytes(), filename);

        return Map.of(
                "status", "SUCCESS",
                "filename", filename,
                "childChunksCreated", chunks,
                "parentSectionsStored", parentStore.size());
    }

    @PostMapping("/documents/text")
    public Map<String, Object> ingestText(
            @RequestBody TextDocumentRequest request) throws IOException {
        int chunks = ingestionService.ingestText(
                request.content(), request.filename());

        return Map.of(
                "status", "SUCCESS",
                "filename", request.filename(),
                "childChunksCreated", chunks,
                "parentSectionsStored", parentStore.size());
    }

    @PostMapping("/rag/query")
    public QueryResponse query(@RequestBody QueryRequest request) {
        if (request.question() == null || request.question().isBlank()) {
            throw new IllegalArgumentException("Question cannot be empty");
        }
        return retrievalService.query(request.question());
    }

    public record TextDocumentRequest(String filename, String content) {
    }
}

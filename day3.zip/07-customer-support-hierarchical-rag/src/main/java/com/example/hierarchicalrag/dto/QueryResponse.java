package com.example.hierarchicalrag.dto;

import java.util.List;

public record QueryResponse(
        String question,
        String answer,
        List<RetrievedSection> sources) {

    public record RetrievedSection(
            String sectionTitle,
            String source,
            String parentId) {
    }
}

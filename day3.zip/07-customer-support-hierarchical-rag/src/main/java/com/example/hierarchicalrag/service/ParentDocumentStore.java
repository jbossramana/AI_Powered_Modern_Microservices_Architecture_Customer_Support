package com.example.hierarchicalrag.service;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ParentDocumentStore {

    @Value("${app.storage.parent-file}")
    private String filePath;

    private final Map<String, String> parents = new ConcurrentHashMap<>();

    @PostConstruct
    public synchronized void load() throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            return;
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
        }

        for (String key : properties.stringPropertyNames()) {
            String encoded = properties.getProperty(key);
            String content = new String(
                    Base64.getDecoder().decode(encoded),
                    StandardCharsets.UTF_8);
            parents.put(key, content);
        }
    }

    public synchronized void save(String parentId, String content)
            throws IOException {
        parents.put(parentId, content);
        persist();
    }

    public String get(String parentId) {
        return parents.get(parentId);
    }

    public int size() {
        return parents.size();
    }

    private synchronized void persist() throws IOException {
        Path path = Paths.get(filePath);
        Path directory = path.getParent();
        if (directory != null) {
            Files.createDirectories(directory);
        }

        Properties properties = new Properties();
        parents.forEach((key, value) -> {
            String encoded = Base64.getEncoder().encodeToString(
                    value.getBytes(StandardCharsets.UTF_8));
            properties.setProperty(key, encoded);
        });

        try (OutputStream output = Files.newOutputStream(path)) {
            properties.store(output, "Hierarchical RAG parent documents");
        }
    }
}


package com.example.hierarchicalrag.service;

// Spring lifecycle annotations.
// PostConstruct: Execute initialization after bean creation.
// PreDestroy: Execute cleanup before bean destruction.
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

// Apache PDFBox classes for extracting text from PDF files.
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

// Spring AI document and vector store classes.
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;

// Inject configuration properties from application.yml.
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

// Java file and directory handling.
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

// Java collection classes.
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

// Regular expressions for detecting document headings.
import java.util.regex.Pattern;


@Service
public class DocumentIngestionService {

    // =========================================================
    // STEP 1: CONFIGURE CHILD CHUNKING
    // =========================================================

    // Maximum target size of each child chunk: 900 characters.
    // This is character-based splitting, not token-based splitting.
    private static final int CHUNK_SIZE = 900;

    // Number of characters shared between consecutive chunks.
    // Overlap helps preserve context across chunk boundaries.
    private static final int CHUNK_OVERLAP = 120;


    // Detect numbered headings such as:
    // 1 Introduction
    // 1.1 Payment Management
    // 1.2.1 Refund Processing
    //
    // These headings help identify logical parent sections.
    private static final Pattern NUMBERED_HEADING =
            Pattern.compile("^\\d+(\\.\\d+)*\\.?\\s+\\S.*");


    // =========================================================
    // STEP 2: DECLARE DEPENDENCIES
    // =========================================================

    // Stores child documents along with their embeddings.
    // Used later for semantic similarity search.
    private final VectorStore vectorStore;

    // Stores complete parent sections as text.
    // Used later to retrieve the parent using parentId.
    private final ParentDocumentStore parentStore;


    // Location of the persisted child vector store.
    // Value is configured in application.yml.
    @Value("${app.storage.vector-file}")
    private String vectorFile;


    // Constructor injection.
    public DocumentIngestionService(
            VectorStore vectorStore,
            ParentDocumentStore parentStore) {

        this.vectorStore = vectorStore;
        this.parentStore = parentStore;
    }


    // =========================================================
    // STEP 3: LOAD EXISTING VECTOR STORE AT APPLICATION STARTUP
    // =========================================================

    @PostConstruct
    public void loadVectorStore() throws IOException {

        // Resolve the configured vector storage file path.
        Path path = Paths.get(vectorFile);

        // Check whether a previously saved vector store exists.
        if (Files.exists(path)) {

            // Load previously persisted child documents,
            // embeddings and metadata into SimpleVectorStore.
            //
            // This avoids generating embeddings again
            // whenever the application restarts.
            simpleStore().load(path.toFile());
        }
    }


    // =========================================================
    // STEP 4: MAIN DOCUMENT INGESTION METHOD
    // =========================================================

    // Accepts extracted document text and its original filename.
    //
    // This method performs the complete parent-child creation:
    //
    // 1. Extract logical sections.
    // 2. Create parent documents.
    // 3. Save parents separately.
    // 4. Split parents into child chunks.
    // 5. Attach parentId metadata to children.
    // 6. Generate embeddings and store children.

    public synchronized int ingestText(
            String text,
            String source) throws IOException {

        // Validate input.
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException(
                    "Document content is empty");
        }


        // -----------------------------------------------------
        // STEP 4.1: EXTRACT LOGICAL SECTIONS
        // -----------------------------------------------------

        // Split the complete document into logical sections
        // based on detected headings.
        //
        // LinkedHashMap preserves the original section order.
        //
        // Key   = Section title
        // Value = Complete section content

        Map<String, StringBuilder> sections =
                extractSections(text);


        // This list will contain all child documents
        // created from all parent sections.
        List<Document> childDocuments = new ArrayList<>();


        // -----------------------------------------------------
        // STEP 4.2: PROCESS EACH SECTION AS A PARENT
        // -----------------------------------------------------

        for (Map.Entry<String, StringBuilder> entry
                : sections.entrySet()) {

            // Extract the section title.
            String sectionTitle = entry.getKey();

            // Extract the complete content of this section.
            String sectionContent =
                    entry.getValue().toString().trim();


            // Ignore empty sections.
            if (sectionContent.isBlank()) {
                continue;
            }


            // -------------------------------------------------
            // STEP 4.3: CREATE A UNIQUE PARENT DOCUMENT ID
            // -------------------------------------------------

            // Every parent section receives a unique identifier.
            //
            // This ID will be attached to all child chunks
            // created from this particular parent section.
            //
            // Example:
            // parentId = "P101"

            String parentId = UUID.randomUUID().toString();


            // Create complete parent content by combining
            // the section title and its entire content.
            //
            // This parent content is NOT embedded.
            // It is stored separately for later retrieval.

            String parentContent =
                    "Section: " + sectionTitle
                    + "\n\n" + sectionContent;


            // -------------------------------------------------
            // STEP 4.4: SAVE COMPLETE PARENT DOCUMENT
            // -------------------------------------------------

            // Save the parent using its unique parentId.
            //
            // ParentDocumentStore maintains the mapping:
            //
            // parentId -> Complete parent content
            //
            // Later, retrieval service uses:
            // parentStore.get(parentId)
            //
            // to retrieve the complete section.

            parentStore.save(parentId, parentContent);


            // -------------------------------------------------
            // STEP 4.5: SPLIT PARENT INTO SMALLER CHILD CHUNKS
            // -------------------------------------------------

            // Split the complete section into smaller pieces.
            //
            // CHUNK_SIZE    = 900 characters
            // CHUNK_OVERLAP = 120 characters
            //
            // Each resulting chunk becomes a child document.
            //
            // Why?
            // Smaller chunks provide more precise semantic
            // similarity search compared to large sections.

            List<String> chunks = splitIntoChunks(
                    sectionContent,
                    CHUNK_SIZE,
                    CHUNK_OVERLAP);


            // Maintain the sequence number of each child
            // within this particular parent section.
            int chunkNumber = 0;


            // -------------------------------------------------
            // STEP 4.6: CREATE CHILD DOCUMENTS WITH METADATA
            // -------------------------------------------------

            for (String chunk : chunks) {

                // Create metadata for the child document.
                Map<String, Object> metadata = new HashMap<>();

                // Critical relationship:
                // Identifies which parent section owns this child.
                metadata.put("parentId", parentId);

                // Original logical section title.
                metadata.put("sectionTitle", sectionTitle);

                // Original document filename.
                metadata.put(
                        "source",
                        source == null ? "unknown" : source);

                // Position of this child within its parent.
                metadata.put("chunkNumber", chunkNumber++);


                // Create a Spring AI Document.
                //
                // Document contains:
                // 1. Child text.
                // 2. Metadata.
                //
                // The parentId metadata is essential for
                // parent retrieval during the query phase.

                childDocuments.add(
                        new Document(
                                "Section: " + sectionTitle
                                + "\n" + chunk,
                                metadata
                        )
                );
            }
        }


        // =====================================================
        // STEP 5: VALIDATE CHILD DOCUMENT CREATION
        // =====================================================

        // If no non-empty child chunks were generated,
        // ingestion cannot continue.

        if (childDocuments.isEmpty()) {

            throw new IllegalArgumentException(
                    "No non-empty sections were found in the document");
        }


        // =====================================================
        // STEP 6: GENERATE EMBEDDINGS AND STORE CHILD DOCUMENTS
        // =====================================================

        // Add all child documents to the vector store.
        //
        // Spring AI internally:
        //
        // 1. Sends child text to the configured EmbeddingModel.
        // 2. Generates a numerical vector for each child.
        // 3. Stores the child document, embedding and metadata.
        //
        // Parent documents are NOT added to this vector store.
        //
        // Only child documents are embedded and indexed.

        vectorStore.add(childDocuments);


        // Persist the updated child vector store to disk.
        saveVectorStore();


        // Return the total number of child chunks created.
        return childDocuments.size();
    }


    // =========================================================
    // STEP 7: PDF DOCUMENT INGESTION
    // =========================================================

    // Accepts PDF file bytes and original filename.
    //
    // PDF is first converted into text.
    // Then the same ingestText() method processes it.
    //
    // Therefore, PDF and plain-text ingestion share
    // the same parent-child creation logic.

    public int ingestPdf(
            byte[] bytes,
            String filename) throws IOException {

        String extractedText;

        // Load PDF from the uploaded byte array.
        // try-with-resources automatically closes the PDF.
        try (PDDocument pdf = Loader.loadPDF(bytes)) {

            // Extract textual content from the PDF.
            PDFTextStripper stripper = new PDFTextStripper();

            extractedText = stripper.getText(pdf);
        }

        // Pass extracted text to the common ingestion method.
        return ingestText(extractedText, filename);
    }


    // =========================================================
    // STEP 8: EXTRACT LOGICAL SECTIONS FROM THE DOCUMENT
    // =========================================================

    // Identifies headings and groups following text
    // into corresponding sections.
    //
    // Example:
    //
    // 1. PAYMENT MANAGEMENT
    //    Payment-related information...
    //
    // 1.1 DUPLICATE PAYMENTS
    //    Duplicate payment information...
    //
    // Result:
    //
    // sections:
    //    "1. PAYMENT MANAGEMENT" -> Content
    //    "1.1 DUPLICATE PAYMENTS" -> Content

    private Map<String, StringBuilder> extractSections(
            String text) {

        // LinkedHashMap maintains section insertion order.
        Map<String, StringBuilder> sections =
                new LinkedHashMap<>();


        // Default section for content appearing
        // before the first recognized heading.
        String currentTitle = "General Information";

        sections.put(
                currentTitle,
                new StringBuilder());


        // Split document text into individual lines.
        // \\R handles different newline formats.
        for (String line : text.split("\\R")) {

            String trimmed = line.trim();

            // Ignore empty lines.
            if (trimmed.isEmpty()) {
                continue;
            }


            // Check whether the current line is a heading.
            if (isHeading(trimmed)) {

                // A new heading starts a new parent section.
                currentTitle = trimmed;

                // Create an empty section for this heading.
                sections.putIfAbsent(
                        currentTitle,
                        new StringBuilder());

            } else {

                // Normal text belongs to the current section.
                sections.get(currentTitle)
                        .append(trimmed)
                        .append('\n');
            }
        }

        // Return all extracted logical sections.
        return sections;
    }


    // =========================================================
    // STEP 9: IDENTIFY WHETHER A LINE IS A HEADING
    // =========================================================

    private boolean isHeading(String line) {

        // Detect numbered headings.
        //
        // Examples:
        // 1 Introduction
        // 1.1 Payment Processing
        // 2.1.1 Refund Approval

        boolean numbered =
                NUMBERED_HEADING.matcher(line).matches();


        // Detect uppercase headings.
        //
        // Examples:
        // PAYMENT MANAGEMENT
        // REFUND PROCESSING
        //
        // Additional checks prevent very short or very long
        // lines from being treated as uppercase headings.

        boolean uppercase =
                line.length() > 3
                && line.length() < 100
                && line.equals(line.toUpperCase(Locale.ROOT))
                && line.matches(".*[A-Z].*");


        // A line is treated as a heading if either
        // numbered-heading or uppercase-heading matches.
        return numbered || uppercase;
    }


    // =========================================================
    // STEP 10: SPLIT A PARENT SECTION INTO CHILD CHUNKS
    // =========================================================

    private List<String> splitIntoChunks(
            String text,
            int chunkSize,
            int overlap) {

        List<String> chunks = new ArrayList<>();

        // Starting character position of the current chunk.
        int start = 0;


        // Continue until the complete section is processed.
        while (start < text.length()) {

            // Calculate the tentative ending position.
            // Do not exceed the document length.
            int end = Math.min(
                    start + chunkSize,
                    text.length());


            // -------------------------------------------------
            // STEP 10.1: TRY TO SPLIT AT A WORD BOUNDARY
            // -------------------------------------------------

            if (end < text.length()) {

                // Find the last space before the target end.
                // This avoids cutting words in the middle.
                int boundary = text.lastIndexOf(' ', end);

                // Use the word boundary only if it is
                // reasonably close to the target chunk size.
                if (boundary > start + chunkSize / 2) {
                    end = boundary;
                }
            }


            // Extract the current child chunk.
            // trim() removes unnecessary leading/trailing spaces.
            String chunk = text.substring(start, end).trim();


            // Add only non-empty child chunks.
            if (!chunk.isBlank()) {
                chunks.add(chunk);
            }


            // Stop when the complete section has been processed.
            if (end >= text.length()) {
                break;
            }


            // -------------------------------------------------
            // STEP 10.2: APPLY OVERLAP
            // -------------------------------------------------

            // Move the starting position backwards by the
            // overlap amount relative to the previous end.
            //
            // Example:
            // Previous chunk ends at character 900.
            // Next chunk starts near character 780.
            //
            // This preserves some context between adjacent chunks.

            start = Math.max(
                    start + 1,
                    end - overlap);
        }

        // Return all generated child chunks.
        return chunks;
    }


    // =========================================================
    // STEP 11: ACCESS THE CONFIGURED SIMPLE VECTOR STORE
    // =========================================================

    private SimpleVectorStore simpleStore() {

        // Convert the injected VectorStore reference
        // to SimpleVectorStore.
        //
        // This implementation specifically uses
        // Spring AI SimpleVectorStore.
        return (SimpleVectorStore) vectorStore;
    }


    // =========================================================
    // STEP 12: PERSIST CHILD VECTORS TO DISK
    // =========================================================

    private synchronized void saveVectorStore()
            throws IOException {

        // Resolve the vector storage file location.
        Path path = Paths.get(vectorFile);

        // Get the parent directory of the storage file.
        Path directory = path.getParent();


        // Create the directory if it does not exist.
        if (directory != null) {
            Files.createDirectories(directory);
        }


        // Save child documents, embeddings and metadata
        // from SimpleVectorStore to the configured file.
        //
        // This allows the vector store to be loaded again
        // when the application restarts.

        simpleStore().save(path.toFile());
    }


    // =========================================================
    // STEP 13: SAVE VECTOR STORE DURING APPLICATION SHUTDOWN
    // =========================================================

    @PreDestroy
    public void shutdown() {

        try {

            // Persist the latest vector store before
            // Spring destroys this service bean.
            saveVectorStore();

        } catch (Exception exception) {

            // Log persistence failure during shutdown.
            System.err.println(
                    "Could not persist vector store: "
                    + exception.getMessage());
        }
    }
}

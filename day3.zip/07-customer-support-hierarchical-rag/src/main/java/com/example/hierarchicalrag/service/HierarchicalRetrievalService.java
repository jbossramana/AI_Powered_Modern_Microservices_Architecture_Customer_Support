
package com.example.hierarchicalrag.service;

import com.example.hierarchicalrag.dto.QueryResponse;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class HierarchicalRetrievalService {

    // Stores child chunks along with their embeddings and metadata.
    // Used for semantic similarity search.
    private final VectorStore vectorStore;

    // Stores complete parent documents (original sections).
    // Used to retrieve the complete context after child retrieval.
    private final ParentDocumentStore parentStore;

    // Used to communicate with the LLM (Ollama).
    private final ChatClient chatClient;


    // Constructor injection of required dependencies.
    public HierarchicalRetrievalService(
            VectorStore vectorStore,
            ParentDocumentStore parentStore,
            ChatClient.Builder chatClientBuilder) {

        this.vectorStore = vectorStore;
        this.parentStore = parentStore;

        // Build the ChatClient using Spring AI configuration.
        this.chatClient = chatClientBuilder.build();
    }


    // Main method: Executes the complete Hierarchical RAG retrieval flow.
    public QueryResponse query(String question) {

        // =====================================================
        // STEP 1: SEARCH CHILD CHUNKS USING VECTOR SIMILARITY
        // =====================================================

        // The customer question is converted into an embedding
        // by the configured EmbeddingModel.
        //
        // VectorStore compares this query embedding with the
        // embeddings of stored child chunks.
        //
        // topK(5) means retrieve up to 5 matching child chunks.
        //
        // similarityThreshold(0.25) filters out results
        // below the configured similarity threshold.

        List<Document> childDocuments =
                vectorStore.similaritySearch(
                        SearchRequest.builder()
                                .query(question)
                                .topK(5)
                                .similarityThreshold(0.25)
                                .build());


        // If no relevant child chunks are found,
        // there is no parent retrieval to perform.
        if (childDocuments == null || childDocuments.isEmpty()) {

            return new QueryResponse(
                    question,
                    "I could not find relevant information in the knowledge base.",
                    List.of());
        }


        // =====================================================
        // STEP 2: EXTRACT parentId AND GROUP CHILD DOCUMENTS
        // =====================================================

        // Every child document contains metadata including:
        //
        // parentId
        // sectionTitle
        // source
        // chunkNumber
        //
        // parentId establishes the relationship between
        // a child chunk and its original parent section.
        //
        // We group children belonging to the same parent.

        Map<String, List<Document>> childrenByParent =
                new LinkedHashMap<>();

        for (Document child : childDocuments) {

            // Read parentId from the child document metadata.
            Object value = child.getMetadata().get("parentId");

            // Ignore children that do not have parentId metadata.
            if (value == null) {
                continue;
            }

            String parentId = value.toString();

            // Create a new list for this parent if necessary,
            // then add the matching child to that list.
            //
            // Multiple children can belong to the same parent.
            childrenByParent.computeIfAbsent(
                    parentId,
                    ignored -> new ArrayList<>()
            ).add(child);
        }


        // =====================================================
        // STEP 3: PREPARE LLM CONTEXT AND SOURCE INFORMATION
        // =====================================================

        // StringBuilder accumulates the complete context
        // that will eventually be sent to the LLM.

        StringBuilder context = new StringBuilder();

        // Collect source information for the final API response.
        List<QueryResponse.RetrievedSection> sources =
                new ArrayList<>();


        // =====================================================
        // STEP 4: RETRIEVE COMPLETE PARENT DOCUMENTS
        // =====================================================

        // Iterate through each unique parent ID and its
        // associated matching child chunks.

        for (Map.Entry<String, List<Document>> entry
                : childrenByParent.entrySet()) {

            String parentId = entry.getKey();

            // IMPORTANT:
            // Retrieve the complete parent section using parentId.
            //
            // Parent documents are NOT retrieved through vector search.
            // They are fetched directly from ParentDocumentStore.
            //
            // This is the parent expansion step in Hierarchical RAG.

            String parentContent = parentStore.get(parentId);

            // If the parent document is missing,
            // skip this parent.
            if (parentContent == null) {
                continue;
            }


            // =================================================
            // STEP 5: BUILD CONTEXT USING PARENT + CHILDREN
            // =================================================

            // Add the complete parent section to the context.
            //
            // Parent provides broader information and preserves
            // the complete meaning of the original section.

            context.append("\n\nPARENT SECTION:\n")
                    .append(parentContent)
                    .append("\nMATCHING CHILD CHUNKS:\n");


            // Add the matching child chunks belonging
            // to this particular parent.
            //
            // Child chunks highlight the information that
            // was identified as relevant by similarity search.

            for (Document child : entry.getValue()) {

                context.append("- ")
                        .append(child.getText())
                        .append('\n');


                // Extract metadata to provide source details
                // in the final QueryResponse.

                Map<String, Object> metadata = child.getMetadata();

                // Record the section title, original filename
                // and parent ID for the retrieved child.
                sources.add(
                        new QueryResponse.RetrievedSection(

                                String.valueOf(
                                        metadata.getOrDefault(
                                                "sectionTitle",
                                                "Unknown section")),

                                String.valueOf(
                                        metadata.getOrDefault(
                                                "source",
                                                "Unknown source")),

                                parentId
                        )
                );
            }
        }


        // =====================================================
        // STEP 6: CHECK WHETHER PARENT CONTEXT WAS RETRIEVED
        // =====================================================

        // Child matches might exist, but their corresponding
        // parent documents might not be available.
        //
        // In that case, we cannot construct the expanded context.

        if (context.isEmpty()) {

            return new QueryResponse(
                    question,
                    "Relevant chunks were found, but their parent sections "
                            + "could not be loaded.",
                    List.of());
        }


        // =====================================================
        // STEP 7: DEFINE SYSTEM PROMPT
        // =====================================================

        // System prompt defines the role and behaviour of the LLM.
        //
        // It instructs the LLM to:
        // 1. Act as an enterprise support assistant.
        // 2. Answer only using retrieved knowledge-base context.
        // 3. Avoid inventing policies or procedures.
        // 4. Clearly mention when information is unavailable.

        String systemPrompt = """
                You are an enterprise customer support assistant.
                Answer only from the supplied knowledge-base context.
                Do not invent policies, procedures, timelines, or approvals.
                If the answer is not present in the context, say that the
                knowledge base does not contain the required information.
                Explain clearly and preserve important conditions and exceptions.
                """;


        // =====================================================
        // STEP 8: PREPARE USER PROMPT
        // =====================================================

        // Combine:
        // 1. Retrieved parent sections.
        // 2. Matching child chunks.
        // 3. Original customer question.
        //
        // This gives the LLM the expanded retrieval context
        // needed to generate an informed answer.

        String userPrompt = """
                KNOWLEDGE-BASE CONTEXT:
                %s

                CUSTOMER QUESTION:
                %s

                Give a concise, accurate answer grounded in the context.
                """.formatted(context, question);


        // =====================================================
        // STEP 9: INVOKE LLM USING SPRING AI ChatClient
        // =====================================================

        // Send system instructions and user prompt to the LLM.
        //
        // call() performs a synchronous LLM invocation.
        //
        // content() extracts the generated response text.

        String answer = chatClient.prompt()
                .system(systemPrompt)
                .user(userPrompt)
                .call()
                .content();


        // =====================================================
        // STEP 10: RETURN FINAL RESPONSE
        // =====================================================

        // Return:
        // 1. Original customer question.
        // 2. LLM-generated answer.
        // 3. Retrieved source sections.
        //
        // The controller serializes this DTO into JSON.

        return new QueryResponse(
                question,
                answer,
                sources);
    }
}

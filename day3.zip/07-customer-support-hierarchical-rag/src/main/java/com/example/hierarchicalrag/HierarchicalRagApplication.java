package com.example.hierarchicalrag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HierarchicalRagApplication {
    public static void main(String[] args) {
        SpringApplication.run(HierarchicalRagApplication.class, args);
    }
}

# Hierarchical RAG 

It is an advanced RAG technique that organizes documents into multiple levels, such as document, section, and paragraph or chunk, to improve information retrieval.

Instead of searching all document chunks independently, Hierarchical RAG uses the document structure to identify relevant information at different levels.

Key idea: Retrieve information from a broad context first, then narrow down to more specific content, or retrieve small chunks and expand to their parent context.

# Why do we need Hierarchical RAG?

In traditional RAG, large documents are split into smaller chunks and stored in a vector database.

However, this can create problems:
- Loss of context: A small chunk may not contain enough information to understand the complete policy.
- Fragmented information: Related information may be spread across multiple chunks.
- Poor retrieval accuracy: Similar chunks may be retrieved without their surrounding context.
- Incomplete answers: The LLM may receive only part of a procedure.

# Customer support example

A customer asks:
"I was charged twice for my subscription. Am I eligible for a refund, and how long will it take?"

The answer may require information from multiple sections of the billing policy:
- Duplicate payment verification
- Refund eligibility
- Refund processing procedure
- Refund timelines

Hierarchical RAG can retrieve the relevant sections while preserving their broader context.


# The parent document file 

It is used to store the original section of a document so that RAG can retrieve complete context after finding a matching child chunk.

Let us understand this using your Customer Support Handbook example.
1. Why do we need a parent document file?
Suppose your handbook contains this section:

# Section 1.1 – Duplicate Payments

If a customer is charged twice for the same subscription, first verify both transactions using the transaction IDs. If both payments are successful, raise a duplicate payment refund request. The refund will normally be processed within 5–7 business days.

During ingestion, we create two types of documents.

Parent document (Complete section)
Stores the complete original section, including all its information.

Child documents(Smaller chunks)
Stores smaller pieces of the parent section. These are embedded and saved in the Vector Database.

# How is the parent file used during a customer query?

Suppose the customer asks:

"I was charged twice. How can I get my money back?"

The retrieval process works like this:
1. Search the Vector Database
   
   Convert the query into an embedding and find matching child chunks.
2. Get the parentId
   
   The matching child chunk contains metadata such as:
   sectionTitle = 1.1 Duplicate Payments
   parentId = 5b98dc0e-7298-44fe-b82b-94bd398e0d5f
3. Read the parent document file
   
   Use that parentId as the key to retrieve the complete section from the parent store.
4. Send complete context to the LLM
   
   The LLM receives the complete section and generates an answer based on it.
   

# Customer Support Hierarchical RAG

A Spring Boot + Spring AI + Ollama demonstration of parent-child
Hierarchical Retrieval-Augmented Generation.

## Technology

- JDK 21
- Spring Boot 4.1.2
- Spring AI 2.0.2
- Ollama chat model: `llama3.2`
- Ollama embedding model: `nomic-embed-text`
- Spring AI `SimpleVectorStore` (embedded, in-process)
- Apache PDFBox for PDF text extraction

> `SimpleVectorStore` is an in-memory store with JSON file persistence. It is
> intended for demonstrations and testing, not production-scale workloads.

## Architecture

1. Parse a PDF or plain-text document.
2. Split the document into sections (parent documents).
3. Split each section into smaller child chunks.
4. Store parent section text in a local Properties file.
5. Embed child chunks with Ollama and index them in SimpleVectorStore.
6. At query time, search child chunks by vector similarity.
7. Read `parentId` metadata and load the associated parent section(s).
8. Send parent context and matching child chunks to the Ollama chat model.

## Prerequisites

1. Install JDK 21.
2. Install Maven 3.9+.
3. Install Ollama.
4. Pull the models:

```bash
ollama pull llama3.2
ollama pull nomic-embed-text
```

Check:

```bash
ollama list
```

Ollama normally listens on `http://localhost:11434`.

## Run

From the project root:

```bash
mvn clean package
mvn spring-boot:run
```

Application base URL: `http://localhost:8080`.

## API 1: Ingest sample handbook as text

Windows CMD:


curl.exe -X POST "http://localhost:8080/api/documents/text" ^
-H "Content-Type: application/json" ^
-d "{\"filename\":\"sample-handbook.txt\",\"content\":\"CUSTOMER SUPPORT HANDBOOK\\n\\n1. PAYMENT MANAGEMENT\\n\\n1.1 Duplicate Payments\\nWhen a customer reports a duplicate payment, verify both transaction IDs and check amount, date and payment status. If both transactions are successful and belong to the same subscription, mark the case as a possible duplicate payment.\\n\\n1.2 Refund Processing\\nA refund request must be initiated only after duplicate payment verification. Create a refund request with the billing department. Refunds require approval. After approval, process the refund to the original payment method.\\n\\n2. SUBSCRIPTION MANAGEMENT\\n\\n2.1 Subscription Cancellation\\nVerify customer identity before processing cancellation.\"}"


You can also upload a PDF.

## API 2: Upload a PDF

Windows CMD:

curl.exe -X POST "http://localhost:8080/api/documents/upload" ^
-H "Content-Type: multipart/form-data" ^
-F "file=@D:\micro\usecase_task\07-customer-support-hierarchical-rag\documents\customer-support-handbook.pdf"

## API 3: Ask a question

Windows CMD:

```cmd
curl.exe -X POST "http://localhost:8080/api/rag/query" ^
-H "Content-Type: application/json" ^
-d "{\"question\":\"How do we handle duplicate payments?\"}"
```

Another question:


curl.exe -X POST "http://localhost:8080/api/rag/query" ^
-H "Content-Type: application/json" ^
-d "{\"question\":\"What is the refund approval procedure?\"}"


## Local persistence

The application creates these files after ingestion:

- `data/child-vectors.json` — serialized child vectors and metadata.
- `data/parent-documents.properties` — parent section content.

The vector store is loaded at application startup and saved after ingestion
and during shutdown.

## Important implementation notes

- The included heading parser is deliberately simple. It recognizes numbered
  headings and short all-uppercase lines. Real PDFs may need a layout-aware
  parser or PDF bookmarks/heading metadata.
- Scanned PDFs require OCR; PDFBox text extraction alone will not read images.
- Re-ingesting the same file currently appends new chunks. For a real system,
  add document IDs, versioning and deletion of old child vectors and parents.
- Add authentication, authorization, tenant filters, upload validation,
  prompt-injection defenses, and observability before production use.
- `SimpleVectorStore` scans its in-memory collection and is not a production
  vector database.

## Hierarchical retrieval in this project

The key relationship is:

```text
Child chunk --metadata.parentId--> Parent section
```

The retrieval service first searches child chunks, groups the results by
`parentId`, loads the full parent section, and provides both parent and child
context to the chat model.
